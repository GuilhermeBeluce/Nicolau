package br.com.cadastrocontribuintes.teste;

import br.com.cadastrocontribuintes.model.Contribuinte;
import br.com.cadastrocontribuintes.repository.ContribuinteRepository;

public class TesteDetalhar {

    public static void main(String[] args) {

        ContribuinteRepository repository = new ContribuinteRepository();

        try {

            Contribuinte contribuinte = repository.detalhar(
                    "123456789",
                    "0000",
                    "09"
            );

            if (contribuinte == null) {

                System.out.println("=================================");
                System.out.println("CONTRIBUINTE NÃO ENCONTRADO!");
                System.out.println("=================================");

                return;
            }

            System.out.println("=================================");
            System.out.println("DETALHAMENTO REALIZADO COM SUCESSO!");
            System.out.println("=================================");

            System.out.println("Documento: "
                    + contribuinte.getDocCorpo()
                    + contribuinte.getDocFilial()
                    + contribuinte.getDocDigito());

            System.out.println("Tipo: "
                    + contribuinte.getTipoDocumento());

            System.out.println("Nome: "
                    + contribuinte.getRazaoSocialNome());

            System.out.println("Faturamento: "
                    + contribuinte.getFaturamentoAnual());

            System.out.println("Data de abertura: "
                    + contribuinte.getDataAbertura());

            System.out.println("Telefone: "
                    + contribuinte.getDddTelefone()
                    + " "
                    + contribuinte.getNumeroTelefone());

            System.out.println("E-mail: "
                    + contribuinte.getEmailCorporativo());

            System.out.println("Cidade: "
                    + contribuinte.getCidadeSede());

            System.out.println("UF: "
                    + contribuinte.getEstadoUf());

            System.out.println("=================================");

        } catch (Exception e) {

            System.err.println("=================================");
            System.err.println("ERRO AO DETALHAR CONTRIBUINTE!");
            System.err.println("=================================");

            e.printStackTrace();
        }
    }
}