package br.com.cadastrocontribuintes.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public final class ConexaoFactory {

    private ConexaoFactory() {
        // Classe utilitária: não deve ser instanciada.
    }

    public static Connection obterConexao() throws SQLException {

        String url = System.getenv("DB_URL");
        String usuario = System.getenv("DB_USER");
        String senha = System.getenv("DB_PASSWORD");

        if (url == null || url.isBlank()) {
            throw new SQLException(
                    "Variável de ambiente DB_URL não definida."
            );
        }

        if (usuario == null || usuario.isBlank()) {
            throw new SQLException(
                    "Variável de ambiente DB_USER não definida."
            );
        }

        if (senha == null) {
            throw new SQLException(
                    "Variável de ambiente DB_PASSWORD não definida."
            );
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException(
                    "Driver JDBC do MySQL não encontrado no classpath da aplicação.",
                    e
            );
        }

        return DriverManager.getConnection(url, usuario, senha);
    }
}