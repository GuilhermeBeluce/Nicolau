package br.com.cadastrocontribuintes.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MunicipioService {

    public List<String> buscarMunicipiosPorUf(String uf) {

        List<String> municipios = new ArrayList<>();

        if (uf == null || uf.isBlank()) {
            return municipios;
        }

        String caminho = "/municipios/" + uf.toUpperCase() + ".txt";

        try (InputStream inputStream =
                     getClass().getResourceAsStream(caminho)) {

            if (inputStream == null) {
                throw new IllegalArgumentException(
                        "Arquivo de municípios não encontrado para a UF: "
                                + uf
                );
            }

            try (BufferedReader reader =
                         new BufferedReader(
                                 new InputStreamReader(
                                         inputStream,
                                         StandardCharsets.UTF_8
                                 ))) {

                String linha;

                while ((linha = reader.readLine()) != null) {

                    linha = linha.trim();

                    if (!linha.isBlank()) {
                        municipios.add(linha);
                    }
                }
            }

        } catch (IOException e) {
            throw new IllegalStateException(
                    "Erro ao ler municípios da UF: " + uf,
                    e
            );
        }

        return municipios;
    }
}