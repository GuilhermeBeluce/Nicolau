package br.com.cadastrocontribuintes.repository;

import br.com.cadastrocontribuintes.config.ConexaoFactory;
import br.com.cadastrocontribuintes.model.Contribuinte;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ContribuinteRepository {

    private static final int LIMITE_MAXIMO_PAGINA = 10;

    private static final int DOCUMENTO_MAXIMO =
            14;

    private static final int NOME_MAXIMO =
            120;

    /*
     * =========================================================
     * VALIDAÇÕES DA PESQUISA - SEÇÃO 9A
     * =========================================================
     */

    private void validarParametrosPesquisa(
            String documento,
            String nome,
            String ordem,
            String direcao,
            int limite,
            int offset) {

        /*
         * Documento já deve chegar normalizado do Bean.
         * Mesmo assim, o Repository valida novamente.
         */
        if (documento != null
                && !documento.isBlank()) {

            if (!documento.matches(
                    "\\d{1," + DOCUMENTO_MAXIMO + "}")) {

                throw new IllegalArgumentException(
                        "Documento de pesquisa inválido."
                );
            }
        }

        /*
         * Nome/Razão Social.
         */
        if (nome != null
                && nome.length() > NOME_MAXIMO) {

            throw new IllegalArgumentException(
                    "Nome/Razão Social de pesquisa inválido."
            );
        }

        /*
         * A ordenação é uma lista branca.
         *
         * REQUISICAO, NOME e DOCUMENTO são aceitos.
         */
        if (!"REQUISICAO".equals(ordem)
                && !"NOME".equals(ordem)
                && !"DOCUMENTO".equals(ordem)) {

            throw new IllegalArgumentException(
                    "Critério de ordenação inválido."
            );
        }

        /*
         * A direção também é uma lista branca.
         */
        if (!"ASC".equals(direcao)
                && !"DESC".equals(direcao)) {

            throw new IllegalArgumentException(
                    "Direção de ordenação inválida."
            );
        }

        /*
         * A página possui no máximo 10 registros.
         */
        if (limite < 1
                || limite > LIMITE_MAXIMO_PAGINA) {

            throw new IllegalArgumentException(
                    "Limite de registros por página inválido."
            );
        }

        /*
         * Offset nunca pode ser negativo.
         */
        if (offset < 0) {

            throw new IllegalArgumentException(
                    "Offset de paginação inválido."
            );
        }
    }

    public void incluir(
            String docCorpo,
            String docFilial,
            String docDigito,
            String tipoDocumento,
            long quantidadeFuncionarios,
            BigDecimal faturamentoAnual,
            LocalDate dataAbertura,
            String razaoSocialNome,
            String nomeFantasia,
            String dddTelefone,
            String numeroTelefone,
            String emailCorporativo,
            String cidadeSede,
            String estadoUf
    ) throws Exception {

        String sql =
                "{CALL sp_contribuinte_incluir(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try (
                Connection conexao = ConexaoFactory.obterConexao();
                CallableStatement stmt = conexao.prepareCall(sql)
        ) {

            stmt.setString(1, docCorpo);
            stmt.setString(2, docFilial);
            stmt.setString(3, docDigito);
            stmt.setString(4, tipoDocumento);
            stmt.setLong(5, quantidadeFuncionarios);
            stmt.setBigDecimal(6, faturamentoAnual);
            stmt.setDate(
                    7,
                    java.sql.Date.valueOf(dataAbertura)
            );
            stmt.setString(8, razaoSocialNome);

            if (nomeFantasia == null) {
                stmt.setNull(9, Types.VARCHAR);
            } else {
                stmt.setString(9, nomeFantasia);
            }

            stmt.setString(10, dddTelefone);
            stmt.setString(11, numeroTelefone);
            stmt.setString(12, emailCorporativo);
            stmt.setString(13, cidadeSede);
            stmt.setString(14, estadoUf);

            stmt.executeUpdate();
        }
    }

    public Contribuinte detalhar(
            String docCorpo,
            String docFilial,
            String docDigito
    ) throws Exception {

        String sql =
                "{CALL sp_contribuinte_detalhar(?, ?, ?)}";

        try (
                Connection conexao = ConexaoFactory.obterConexao();
                CallableStatement stmt = conexao.prepareCall(sql)
        ) {

            stmt.setString(1, docCorpo);
            stmt.setString(2, docFilial);
            stmt.setString(3, docDigito);

            try (var resultado = stmt.executeQuery()) {

                if (!resultado.next()) {
                    return null;
                }

                Contribuinte contribuinte =
                        new Contribuinte();

                contribuinte.setNumeroRequisicao(
                        resultado.getLong("numero_requisicao")
                );

                contribuinte.setDocCorpo(
                        resultado.getString("doc_corpo")
                );

                contribuinte.setDocFilial(
                        resultado.getString("doc_filial")
                );

                contribuinte.setDocDigito(
                        resultado.getString("doc_digito")
                );

                contribuinte.setTipoDocumento(
                        resultado.getString("tipo_documento")
                );

                contribuinte.setQuantidadeFuncionarios(
                        resultado.getLong("quantidade_funcionarios")
                );

                contribuinte.setFaturamentoAnual(
                        resultado.getBigDecimal("faturamento_anual")
                );

                contribuinte.setDataAbertura(
                        resultado.getDate("data_abertura")
                                .toLocalDate()
                );

                contribuinte.setRazaoSocialNome(
                        resultado.getString("razao_social_nome")
                );

                contribuinte.setNomeFantasia(
                        resultado.getString("nome_fantasia")
                );

                contribuinte.setDddTelefone(
                        resultado.getString("ddd_telefone")
                );

                contribuinte.setNumeroTelefone(
                        resultado.getString("numero_telefone")
                );

                contribuinte.setEmailCorporativo(
                        resultado.getString("email_corporativo")
                );

                contribuinte.setCidadeSede(
                        resultado.getString("cidade_sede")
                );

                contribuinte.setEstadoUf(
                        resultado.getString("estado_uf")
                );

                return contribuinte;
            }
        }
    }

    public List<Contribuinte> pesquisar(
            Long numeroRequisicao,
            String documento,
            String nome,
            String ordem,
            String direcao,
            int limite,
            int offset
    ) throws Exception {

        validarParametrosPesquisa(
                documento,
                nome,
                ordem,
                direcao,
                limite,
                offset
        );

        String sql =
                "{CALL sp_contribuinte_pesquisar(?, ?, ?, ?, ?, ?, ?)}";

        List<Contribuinte> lista =
                new ArrayList<>();

        try (
                Connection conexao = ConexaoFactory.obterConexao();
                CallableStatement stmt = conexao.prepareCall(sql)
        ) {

            if (numeroRequisicao == null) {
                stmt.setNull(1, Types.BIGINT);
            } else {
                stmt.setLong(1, numeroRequisicao);
            }

            if (documento == null
                    || documento.isBlank()) {

                stmt.setNull(
                        2,
                        Types.VARCHAR
                );

            } else {

                stmt.setString(
                        2,
                        documento
                );
            }

            if (nome == null
                    || nome.isBlank()) {

                stmt.setNull(
                        3,
                        Types.VARCHAR
                );

            } else {

                stmt.setString(
                        3,
                        nome
                );
            }

            if (ordem == null
                    || ordem.isBlank()) {

                stmt.setNull(
                        4,
                        Types.VARCHAR
                );

            } else {

                stmt.setString(
                        4,
                        ordem
                );
            }

            if (direcao == null
                    || direcao.isBlank()) {

                stmt.setNull(
                        5,
                        Types.VARCHAR
                );

            } else {

                stmt.setString(
                        5,
                        direcao
                );
            }

            stmt.setInt(6, limite);
            stmt.setInt(7, offset);

            try (var resultado = stmt.executeQuery()) {

                while (resultado.next()) {

                    Contribuinte contribuinte =
                            new Contribuinte();

                    contribuinte.setNumeroRequisicao(
                            resultado.getLong("numero_requisicao")
                    );

                    contribuinte.setDocCorpo(
                            resultado.getString("doc_corpo")
                    );

                    contribuinte.setDocFilial(
                            resultado.getString("doc_filial")
                    );

                    contribuinte.setDocDigito(
                            resultado.getString("doc_digito")
                    );

                    contribuinte.setTipoDocumento(
                            resultado.getString("tipo_documento")
                    );

                    contribuinte.setQuantidadeFuncionarios(
                            resultado.getLong("quantidade_funcionarios")
                    );

                    contribuinte.setFaturamentoAnual(
                            resultado.getBigDecimal("faturamento_anual")
                    );

                    contribuinte.setDataAbertura(
                            resultado.getDate("data_abertura")
                                    .toLocalDate()
                    );

                    contribuinte.setRazaoSocialNome(
                            resultado.getString("razao_social_nome")
                    );

                    contribuinte.setNomeFantasia(
                            resultado.getString("nome_fantasia")
                    );

                    contribuinte.setDddTelefone(
                            resultado.getString("ddd_telefone")
                    );

                    contribuinte.setNumeroTelefone(
                            resultado.getString("numero_telefone")
                    );

                    contribuinte.setEmailCorporativo(
                            resultado.getString("email_corporativo")
                    );

                    contribuinte.setCidadeSede(
                            resultado.getString("cidade_sede")
                    );

                    contribuinte.setEstadoUf(
                            resultado.getString("estado_uf")
                    );

                    lista.add(contribuinte);
                }
            }
        }

        return lista;
    }

    /*
     * =========================================================
     * CONTAGEM PARA PAGINAÇÃO
     * =========================================================
     */

    public long contar(
            Long numeroRequisicao,
            String documento,
            String nome
    ) throws Exception {

        /*
         * A contagem recebe os mesmos filtros normalizados
         * utilizados pela pesquisa.
         */
        if (documento != null
                && !documento.isBlank()
                && !documento.matches(
                "\\d{1," + DOCUMENTO_MAXIMO + "}")) {

            throw new IllegalArgumentException(
                    "Documento de pesquisa inválido."
            );
        }

        if (nome != null
                && nome.length() > NOME_MAXIMO) {

            throw new IllegalArgumentException(
                    "Nome/Razão Social de pesquisa inválido."
            );
        }

        String sql =
                "{CALL sp_contribuinte_contar(?, ?, ?)}";

        try (
                Connection conexao = ConexaoFactory.obterConexao();
                CallableStatement stmt = conexao.prepareCall(sql)
        ) {

            if (numeroRequisicao == null) {

                stmt.setNull(
                        1,
                        Types.BIGINT
                );

            } else {

                stmt.setLong(
                        1,
                        numeroRequisicao
                );
            }

            if (documento == null
                    || documento.isBlank()) {

                stmt.setNull(
                        2,
                        Types.VARCHAR
                );

            } else {

                stmt.setString(
                        2,
                        documento
                );
            }

            if (nome == null
                    || nome.isBlank()) {

                stmt.setNull(
                        3,
                        Types.VARCHAR
                );

            } else {

                stmt.setString(
                        3,
                        nome
                );
            }

            try (var resultado = stmt.executeQuery()) {

                if (resultado.next()) {

                    return resultado.getLong("total");
                }
            }
        }

        return 0;
    }

    public void alterar(
            String docCorpo,
            String docFilial,
            String docDigito,
            String tipoDocumento,
            long quantidadeFuncionarios,
            BigDecimal faturamentoAnual,
            LocalDate dataAbertura,
            String razaoSocialNome,
            String nomeFantasia,
            String dddTelefone,
            String numeroTelefone,
            String emailCorporativo,
            String cidadeSede,
            String estadoUf
    ) throws Exception {

        String sql =
                "{CALL sp_contribuinte_alterar(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)}";

        try (
                Connection conexao = ConexaoFactory.obterConexao();
                CallableStatement stmt = conexao.prepareCall(sql)
        ) {

            stmt.setString(1, docCorpo);
            stmt.setString(2, docFilial);
            stmt.setString(3, docDigito);
            stmt.setString(4, tipoDocumento);
            stmt.setLong(5, quantidadeFuncionarios);
            stmt.setBigDecimal(6, faturamentoAnual);
            stmt.setDate(
                    7,
                    java.sql.Date.valueOf(dataAbertura)
            );
            stmt.setString(8, razaoSocialNome);

            if (nomeFantasia == null) {

                stmt.setNull(
                        9,
                        Types.VARCHAR
                );

            } else {

                stmt.setString(
                        9,
                        nomeFantasia
                );
            }

            stmt.setString(10, dddTelefone);
            stmt.setString(11, numeroTelefone);
            stmt.setString(12, emailCorporativo);
            stmt.setString(13, cidadeSede);
            stmt.setString(14, estadoUf);

            stmt.executeUpdate();
        }
    }

    public void excluir(
            String docCorpo,
            String docFilial,
            String docDigito
    ) throws Exception {

        String sql =
                "{CALL sp_contribuinte_excluir(?, ?, ?)}";

        try (
                Connection conexao = ConexaoFactory.obterConexao();
                CallableStatement stmt = conexao.prepareCall(sql)
        ) {

            stmt.setString(1, docCorpo);
            stmt.setString(2, docFilial);
            stmt.setString(3, docDigito);

            stmt.executeUpdate();
        }
    }
}