package br.com.cadastrocontribuintes.teste;

import br.com.cadastrocontribuintes.model.Contribuinte;
import br.com.cadastrocontribuintes.repository.ContribuinteRepository;

import java.util.List;

public class TestePesquisa {

    public static void main(String[] args) {

        ContribuinteRepository repository =
                new ContribuinteRepository();

        try {

            List<Contribuinte> lista =
                    repository.pesquisar(
                            null,
                            null,
                            null,
                            "REQUISICAO",
                            "ASC",
                            10,
                            0
                    );

            System.out.println("=================================");
            System.out.println("PESQUISA REALIZADA COM SUCESSO!");
            System.out.println(
                    "Quantidade encontrada: "
                            + lista.size()
            );
            System.out.println("=================================");

            for (Contribuinte contribuinte : lista) {

                System.out.println(
                        "Requisição: "
                                + String.format(
                                "%03d",
                                contribuinte.getNumeroRequisicao()
                        )
                );

                System.out.println(
                        "Documento: "
                                + contribuinte.getDocCorpo()
                                + contribuinte.getDocFilial()
                                + contribuinte.getDocDigito()
                );

                System.out.println(
                        "Tipo: "
                                + contribuinte.getTipoDocumento()
                );

                System.out.println(
                        "Nome: "
                                + contribuinte.getRazaoSocialNome()
                );

                System.out.println("---------------------------------");
            }

        } catch (Exception e) {

            System.err.println(
                    "================================="
            );

            System.err.println(
                    "ERRO AO PESQUISAR CONTRIBUINTES!"
            );

            System.err.println(
                    "================================="
            );

            e.printStackTrace();
        }
    }
}