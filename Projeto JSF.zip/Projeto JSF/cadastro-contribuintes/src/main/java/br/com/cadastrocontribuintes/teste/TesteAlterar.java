package br.com.cadastrocontribuintes.teste;

import br.com.cadastrocontribuintes.repository.ContribuinteRepository;

import java.math.BigDecimal;
import java.time.LocalDate;

public class TesteAlterar {

    public static void main(String[] args) {

        ContribuinteRepository repository = new ContribuinteRepository();

        try {

            repository.alterar(
                    "123456789",
                    "0000",
                    "09",
                    "CPF",
                    0,
                    new BigDecimal("90000.00"),
                    LocalDate.of(1990, 5, 15),
                    "João da Silva Alterado",
                    null,
                    "47",
                    "977777777",
                    "joao.alterado@empresa.com.br",
                    "Joinville",
                    "SC"
            );

            System.out.println("=================================");
            System.out.println("ALTERAÇÃO REALIZADA COM SUCESSO!");
            System.out.println("=================================");

            System.out.println("Novo nome: João da Silva Alterado");
            System.out.println("Novo faturamento: 90000.00");
            System.out.println("Novo telefone: 47 977777777");
            System.out.println("Novo e-mail: joao.alterado@empresa.com.br");

            System.out.println("=================================");

        } catch (Exception e) {

            System.err.println("=================================");
            System.err.println("ERRO AO ALTERAR CONTRIBUINTE!");
            System.err.println("=================================");

            e.printStackTrace();
        }
    }
}