package br.com.cadastrocontribuintes.teste;

import br.com.cadastrocontribuintes.config.ConexaoFactory;

import java.sql.Connection;

public class TesteConexao {

    public static void main(String[] args) {

        try (Connection conexao = ConexaoFactory.obterConexao()) {

            System.out.println("=================================");
            System.out.println("CONEXÃO COM O MYSQL OK!");
            System.out.println("Banco: " + conexao.getCatalog());
            System.out.println("=================================");

        } catch (Exception e) {

            System.err.println("=================================");
            System.err.println("ERRO AO CONECTAR COM O MYSQL!");
            System.err.println("=================================");

            e.printStackTrace();
        }
    }
}