package br.com.cadastrocontribuintes.model;

import java.math.BigDecimal;
import java.time.LocalDate;

public class Contribuinte {

    private long numeroRequisicao;

    private String docCorpo;
    private String docFilial;
    private String docDigito;
    private String tipoDocumento;

    private long quantidadeFuncionarios;

    private BigDecimal faturamentoAnual;
    private LocalDate dataAbertura;
    private String razaoSocialNome;
    private String nomeFantasia;
    private String dddTelefone;
    private String numeroTelefone;
    private String emailCorporativo;
    private String cidadeSede;
    private String estadoUf;

    public long getNumeroRequisicao() {
        return numeroRequisicao;
    }

    public void setNumeroRequisicao(long numeroRequisicao) {
        this.numeroRequisicao = numeroRequisicao;
    }

    public String getDocCorpo() {
        return docCorpo;
    }

    public void setDocCorpo(String docCorpo) {
        this.docCorpo = docCorpo;
    }

    public String getDocFilial() {
        return docFilial;
    }

    public void setDocFilial(String docFilial) {
        this.docFilial = docFilial;
    }

    public String getDocDigito() {
        return docDigito;
    }

    public void setDocDigito(String docDigito) {
        this.docDigito = docDigito;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public long getQuantidadeFuncionarios() {
        return quantidadeFuncionarios;
    }

    public void setQuantidadeFuncionarios(long quantidadeFuncionarios) {
        this.quantidadeFuncionarios = quantidadeFuncionarios;
    }

    public BigDecimal getFaturamentoAnual() {
        return faturamentoAnual;
    }

    public void setFaturamentoAnual(BigDecimal faturamentoAnual) {
        this.faturamentoAnual = faturamentoAnual;
    }

    public LocalDate getDataAbertura() {
        return dataAbertura;
    }

    public void setDataAbertura(LocalDate dataAbertura) {
        this.dataAbertura = dataAbertura;
    }

    public String getRazaoSocialNome() {
        return razaoSocialNome;
    }

    public void setRazaoSocialNome(String razaoSocialNome) {
        this.razaoSocialNome = razaoSocialNome;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getDddTelefone() {
        return dddTelefone;
    }

    public void setDddTelefone(String dddTelefone) {
        this.dddTelefone = dddTelefone;
    }

    public String getNumeroTelefone() {
        return numeroTelefone;
    }

    public void setNumeroTelefone(String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }

    public String getEmailCorporativo() {
        return emailCorporativo;
    }

    public void setEmailCorporativo(String emailCorporativo) {
        this.emailCorporativo = emailCorporativo;
    }

    public String getCidadeSede() {
        return cidadeSede;
    }

    public void setCidadeSede(String cidadeSede) {
        this.cidadeSede = cidadeSede;
    }

    public String getEstadoUf() {
        return estadoUf;
    }

    public void setEstadoUf(String estadoUf) {
        this.estadoUf = estadoUf;
    }
}