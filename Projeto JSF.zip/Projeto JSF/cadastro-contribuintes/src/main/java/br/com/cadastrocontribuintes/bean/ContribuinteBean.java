package br.com.cadastrocontribuintes.bean;

import br.com.cadastrocontribuintes.model.Contribuinte;
import br.com.cadastrocontribuintes.repository.ContribuinteRepository;
import br.com.cadastrocontribuintes.service.MunicipioService;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Named;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Named
@ViewScoped
public class ContribuinteBean implements Serializable {

    private static final long serialVersionUID = 1L;

    private static final String FLASH_CONTRIBUINTE =
            "contribuinteConsultado";

    private static final String FLASH_CONTRIBUINTE_EXCLUSAO =
            "contribuinteExclusao";

    private static final String FLASH_ESTADO_LISTA =
            "estadoListaContribuintes";

    private static final DateTimeFormatter
            FORMATADOR_DATA =
            DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private static final int REGISTROS_POR_PAGINA = 10;

    private static final int DOCUMENTO_PESQUISA_MAXIMO = 14;

    private static final int NOME_PESQUISA_MAXIMO = 120;

    private static final int NOME_MINIMO = 3;

    private static final int NOME_MAXIMO = 120;

    private static final int NOME_FANTASIA_MAXIMO = 80;

    private static final int EMAIL_MAXIMO = 100;

    private static final int CIDADE_MAXIMO = 60;

    private static final BigDecimal FATURAMENTO_MAXIMO =
            new BigDecimal("9999999999999.99");

    private static final long QUANTIDADE_FUNCIONARIOS_MAXIMA =
            4_294_967_295L;

    /*
     * =========================================================
     * UFs VÁLIDAS
     * =========================================================
     */

    private static final Set<String> UFS_VALIDAS = Set.of(
            "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES",
            "GO", "MA", "MT", "MS", "MG", "PA", "PB", "PR",
            "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC",
            "SP", "SE", "TO"
    );

    /*
     * =========================================================
     * DDDS VÁLIDOS
     * =========================================================
     */

    private static final Set<String> DDDS_VALIDOS = Set.of(
            "11", "12", "13", "14", "15", "16", "17", "18", "19",
            "21", "22", "24", "27", "28",
            "31", "32", "33", "34", "35", "37", "38",
            "41", "42", "43", "44", "45", "46",
            "47", "48", "49",
            "51", "53", "54", "55",
            "61", "62", "63", "64", "65", "66", "67",
            "68", "69",
            "71", "73", "74", "75", "77", "79",
            "81", "82", "83", "84", "85", "86", "87", "88", "89",
            "91", "92", "93", "94", "95", "96", "97", "98", "99"
    );

    /*
     * =========================================================
     * OBJETO PRINCIPAL
     * =========================================================
     */

    private Contribuinte contribuinte =
            new Contribuinte();

    private Contribuinte contribuinteOriginal;

    private String documento;

    private List<String> municipios =
            new ArrayList<>();

    private List<Contribuinte> contribuintes =
            new ArrayList<>();

    /*
     * =========================================================
     * FILTROS DA PESQUISA
     * =========================================================
     */

    private Long filtroNumeroRequisicao;

    private String filtroDocumento;

    private String filtroNome;

    /*
     * =========================================================
     * ORDENAÇÃO
     * =========================================================
     */

    private String ordenarPor = "REQUISICAO";

    private String direcaoOrdenacao = "ASC";

    /*
     * =========================================================
     * PAGINAÇÃO
     * =========================================================
     */

    private int paginaAtual = 1;

    private long totalRegistros = 0;

    private int totalPaginas = 1;

    /*
     * =========================================================
     * REPOSITÓRIO E SERVIÇO
     * =========================================================
     */

    private final ContribuinteRepository repository =
            new ContribuinteRepository();

    private final MunicipioService municipioService =
            new MunicipioService();

    /*
     * =========================================================
     * ESTADO DA LISTAGEM
     * =========================================================
     */

    private static class EstadoLista
            implements Serializable {

        private static final long serialVersionUID = 1L;

        private Long filtroNumeroRequisicao;

        private String filtroDocumento;

        private String filtroNome;

        private String ordenarPor;

        private String direcaoOrdenacao;

        private int paginaAtual;

        public EstadoLista(
                Long filtroNumeroRequisicao,
                String filtroDocumento,
                String filtroNome,
                String ordenarPor,
                String direcaoOrdenacao,
                int paginaAtual) {

            this.filtroNumeroRequisicao =
                    filtroNumeroRequisicao;

            this.filtroDocumento =
                    filtroDocumento;

            this.filtroNome =
                    filtroNome;

            this.ordenarPor =
                    ordenarPor;

            this.direcaoOrdenacao =
                    direcaoOrdenacao;

            this.paginaAtual =
                    paginaAtual;
        }
    }

    /*
     * =========================================================
     * INICIALIZAÇÃO DA VIEW
     * =========================================================
     */

    @PostConstruct
    public void inicializar() {

        FacesContext contexto =
                FacesContext.getCurrentInstance();

        Object contribuinteExclusaoFlash =
                contexto.getExternalContext()
                        .getFlash()
                        .get(FLASH_CONTRIBUINTE_EXCLUSAO);

        if (contribuinteExclusaoFlash
                instanceof Contribuinte) {

            contribuinte =
                    (Contribuinte) contribuinteExclusaoFlash;

        } else {

            Object contribuinteFlash =
                    contexto.getExternalContext()
                            .getFlash()
                            .get(FLASH_CONTRIBUINTE);

            if (contribuinteFlash
                    instanceof Contribuinte) {

                contribuinte =
                        (Contribuinte) contribuinteFlash;

                contribuinteOriginal =
                        copiarContribuinte(contribuinte);
            }
        }

        if (contribuinte != null
                && contribuinte.getEstadoUf() != null
                && !contribuinte.getEstadoUf().isBlank()) {

            municipios =
                    municipioService.buscarMunicipiosPorUf(
                            contribuinte.getEstadoUf()
                    );
        }

        Object estadoListaFlash =
                contexto.getExternalContext()
                        .getFlash()
                        .get(FLASH_ESTADO_LISTA);

        if (estadoListaFlash instanceof EstadoLista) {

            EstadoLista estado =
                    (EstadoLista) estadoListaFlash;

            filtroNumeroRequisicao =
                    estado.filtroNumeroRequisicao;

            filtroDocumento =
                    estado.filtroDocumento;

            filtroNome =
                    estado.filtroNome;

            ordenarPor =
                    estado.ordenarPor;

            direcaoOrdenacao =
                    estado.direcaoOrdenacao;

            paginaAtual =
                    estado.paginaAtual;

            carregarPagina();
        }
    }

    /*
     * =========================================================
     * ALTERAR TIPO DE DOCUMENTO
     * =========================================================
     */

    public void alterarTipoDocumento() {

        documento = null;

        contribuinte.setDocCorpo(null);

        contribuinte.setDocFilial(null);

        contribuinte.setDocDigito(null);

        contribuinte.setNomeFantasia(null);

        contribuinte.setQuantidadeFuncionarios(0);
    }

    /*
     * =========================================================
     * CARGA POR IDENTIFICADOR RECEBIDO PELA URL
     * =========================================================
     */

    public String carregarPorIdentificadorUrl() {

        FacesContext contexto =
                FacesContext.getCurrentInstance();

        String tipoDocumento =
                contexto.getExternalContext()
                        .getRequestParameterMap()
                        .get("tipo_documento");

        String documentoUrl =
                contexto.getExternalContext()
                        .getRequestParameterMap()
                        .get("documento");

        if (tipoDocumento == null
                && documentoUrl == null) {

            return null;
        }

        try {

            String tipoNormalizado =
                    normalizarTipoDocumento(
                            tipoDocumento
                    );

            String documentoNormalizado =
                    normalizarDocumentoUrl(
                            documentoUrl
                    );

            if (!validarIdentificadorUrl(
                    tipoNormalizado,
                    documentoNormalizado)) {

                return "lista?faces-redirect=true";
            }

            String docCorpo;
            String docFilial;
            String docDigito;

            if ("CPF".equals(tipoNormalizado)) {

                docCorpo =
                        documentoNormalizado.substring(0, 9);

                docFilial = "0000";

                docDigito =
                        documentoNormalizado.substring(9, 11);

            } else {

                docCorpo =
                        documentoNormalizado.substring(0, 8);

                docFilial =
                        documentoNormalizado.substring(8, 12);

                docDigito =
                        documentoNormalizado.substring(12, 14);
            }

            if (!validarChaveDocumento(
                    docCorpo,
                    docFilial,
                    docDigito)) {

                return "lista?faces-redirect=true";
            }

            Contribuinte resultado =
                    repository.detalhar(
                            docCorpo,
                            docFilial,
                            docDigito
                    );

            if (resultado == null) {

                adicionarMensagemErro(
                        "O contribuinte não foi localizado. "
                                + "Atualize a listagem e tente novamente."
                );

                return "lista?faces-redirect=true";
            }

            contribuinte = resultado;

            contribuinteOriginal =
                    copiarContribuinte(resultado);

            if (resultado.getEstadoUf() != null
                    && !resultado.getEstadoUf().isBlank()) {

                municipios =
                        municipioService.buscarMunicipiosPorUf(
                                resultado.getEstadoUf()
                        );
            }

            carregarEstadoListaDaUrl();

            salvarEstadoListaNoFlash();

            return null;

        } catch (Exception e) {

            System.err.println(
                    "ERRO AO CARREGAR CONTRIBUINTE PELO IDENTIFICADOR DA URL!"
            );

            e.printStackTrace();

            adicionarMensagemErro(
                    "Não foi possível concluir a operação. Tente novamente."
            );

            return "lista?faces-redirect=true";
        }
    }

    /*
     * =========================================================
     * NORMALIZAÇÃO DO TIPO
     * =========================================================
     */

    private String normalizarTipoDocumento(
            String tipoDocumento) {

        if (tipoDocumento == null) {
            return "";
        }

        return tipoDocumento
                .trim()
                .toUpperCase();
    }

    /*
     * =========================================================
     * NORMALIZAÇÃO DO DOCUMENTO DA URL
     * =========================================================
     */

    private String normalizarDocumentoUrl(
            String documentoUrl) {

        if (documentoUrl == null) {
            return "";
        }

        String documentoNormalizado =
                documentoUrl.trim();

        if (!documentoNormalizado.matches("\\d+")) {
            return "";
        }

        return documentoNormalizado;
    }

    /*
     * =========================================================
     * VALIDAÇÃO DO IDENTIFICADOR DA URL
     * =========================================================
     */

    private boolean validarIdentificadorUrl(
            String tipoDocumento,
            String documentoUrl) {

        if (!"CPF".equals(tipoDocumento)
                && !"CNPJ".equals(tipoDocumento)) {

            adicionarMensagemErro(
                    "Tipo de documento informado na URL é inválido."
            );

            return false;
        }

        if (documentoUrl == null
                || documentoUrl.isBlank()) {

            adicionarMensagemErro(
                    "Documento informado na URL é inválido."
            );

            return false;
        }

        if (!documentoUrl.matches("\\d+")) {

            adicionarMensagemErro(
                    "Documento informado na URL deve conter apenas dígitos."
            );

            return false;
        }

        if ("CPF".equals(tipoDocumento)
                && documentoUrl.length() != 11) {

            adicionarMensagemErro(
                    "CPF informado na URL deve conter 11 dígitos."
            );

            return false;
        }

        if ("CNPJ".equals(tipoDocumento)
                && documentoUrl.length() != 14) {

            adicionarMensagemErro(
                    "CNPJ informado na URL deve conter 14 dígitos."
            );

            return false;
        }

        return true;
    }

    /*
     * =========================================================
     * RECUPERAR ESTADO DA LISTA PELA URL
     * =========================================================
     */

    private void carregarEstadoListaDaUrl() {

        FacesContext contexto =
                FacesContext.getCurrentInstance();

        var parametros =
                contexto.getExternalContext()
                        .getRequestParameterMap();

        String requisicao =
                parametros.get("filtroNumeroRequisicao");

        String documentoFiltro =
                parametros.get("filtroDocumento");

        String nomeFiltro =
                parametros.get("filtroNome");

        String ordem =
                parametros.get("ordenarPor");

        String direcao =
                parametros.get("direcaoOrdenacao");

        String pagina =
                parametros.get("pagina");

        if (requisicao == null
                || requisicao.isBlank()) {

            filtroNumeroRequisicao = null;

        } else {

            try {

                long valor =
                        Long.parseLong(
                                requisicao.trim()
                        );

                if (valor < 0) {

                    filtroNumeroRequisicao = null;

                } else {

                    filtroNumeroRequisicao = valor;
                }

            } catch (NumberFormatException e) {

                filtroNumeroRequisicao = null;
            }
        }

        filtroDocumento = documentoFiltro;

        filtroNome = nomeFiltro;

        if ("REQUISICAO".equals(ordem)
                || "NOME".equals(ordem)
                || "DOCUMENTO".equals(ordem)) {

            ordenarPor = ordem;
        }

        if ("ASC".equals(direcao)
                || "DESC".equals(direcao)) {

            direcaoOrdenacao = direcao;
        }

        if (pagina != null
                && !pagina.isBlank()) {

            try {

                int paginaInformada =
                        Integer.parseInt(
                                pagina.trim()
                        );

                if (paginaInformada >= 1) {

                    paginaAtual = paginaInformada;
                }

            } catch (NumberFormatException ignored) {

                paginaAtual = 1;
            }
        }
    }

    /*
     * =========================================================
     * SALVAR ESTADO DA LISTA
     * =========================================================
     */

    private void salvarEstadoListaNoFlash() {

        FacesContext contexto =
                FacesContext.getCurrentInstance();

        EstadoLista estadoLista =
                new EstadoLista(
                        filtroNumeroRequisicao,
                        filtroDocumento,
                        filtroNome,
                        ordenarPor,
                        direcaoOrdenacao,
                        paginaAtual
                );

        contexto.getExternalContext()
                .getFlash()
                .put(
                        FLASH_ESTADO_LISTA,
                        estadoLista
                );
    }

    /*
     * =========================================================
     * CÓPIA DO CONTRIBUINTE
     * =========================================================
     */

    private Contribuinte copiarContribuinte(
            Contribuinte origem) {

        if (origem == null) {
            return null;
        }

        Contribuinte copia =
                new Contribuinte();

        copia.setNumeroRequisicao(
                origem.getNumeroRequisicao()
        );

        copia.setDocCorpo(
                origem.getDocCorpo()
        );

        copia.setDocFilial(
                origem.getDocFilial()
        );

        copia.setDocDigito(
                origem.getDocDigito()
        );

        copia.setTipoDocumento(
                origem.getTipoDocumento()
        );

        copia.setQuantidadeFuncionarios(
                origem.getQuantidadeFuncionarios()
        );

        copia.setFaturamentoAnual(
                origem.getFaturamentoAnual()
        );

        copia.setDataAbertura(
                origem.getDataAbertura()
        );

        copia.setRazaoSocialNome(
                origem.getRazaoSocialNome()
        );

        copia.setNomeFantasia(
                origem.getNomeFantasia()
        );

        copia.setDddTelefone(
                origem.getDddTelefone()
        );

        copia.setNumeroTelefone(
                origem.getNumeroTelefone()
        );

        copia.setEmailCorporativo(
                origem.getEmailCorporativo()
        );

        copia.setCidadeSede(
                origem.getCidadeSede()
        );

        copia.setEstadoUf(
                origem.getEstadoUf()
        );

        return copia;
    }

    /*
     * =========================================================
     * GETTERS E SETTERS
     * =========================================================
     */

    public Contribuinte getContribuinte() {
        return contribuinte;
    }

    public void setContribuinte(
            Contribuinte contribuinte) {

        this.contribuinte = contribuinte;
    }

    public String getDocumento() {
        return documento;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public List<String> getMunicipios() {
        return municipios;
    }

    public List<Contribuinte> getContribuintes() {
        return contribuintes;
    }

    /*
     * =========================================================
     * FORMATAÇÃO DO DOCUMENTO
     * =========================================================
     */

    public String getDocumentoFormatado() {

        if (contribuinte == null
                || contribuinte.getTipoDocumento() == null) {

            return "";
        }

        String corpo =
                contribuinte.getDocCorpo();

        String filial =
                contribuinte.getDocFilial();

        String digito =
                contribuinte.getDocDigito();

        if (corpo == null
                || filial == null
                || digito == null) {

            return "";
        }

        if ("CPF".equals(
                contribuinte.getTipoDocumento())) {

            return corpo.substring(0, 3)
                    + "."
                    + corpo.substring(3, 6)
                    + "."
                    + corpo.substring(6, 9)
                    + "-"
                    + digito;
        }

        if ("CNPJ".equals(
                contribuinte.getTipoDocumento())) {

            return corpo.substring(0, 2)
                    + "."
                    + corpo.substring(2, 5)
                    + "."
                    + corpo.substring(5, 8)
                    + "/"
                    + filial
                    + "-"
                    + digito;
        }

        return corpo + filial + digito;
    }

    /*
     * =========================================================
     * DOCUMENTO DA LISTAGEM
     * =========================================================
     */

    public String getDocumentoLista(
            Contribuinte contribuinte) {

        if (contribuinte == null
                || contribuinte.getTipoDocumento() == null
                || contribuinte.getDocCorpo() == null
                || contribuinte.getDocDigito() == null) {

            return "";
        }

        String corpo =
                contribuinte.getDocCorpo();

        String filial =
                contribuinte.getDocFilial();

        String digito =
                contribuinte.getDocDigito();

        if ("CPF".equals(
                contribuinte.getTipoDocumento())) {

            return corpo + digito;
        }

        if ("CNPJ".equals(
                contribuinte.getTipoDocumento())) {

            if (filial == null) {
                return "";
            }

            return corpo + filial + digito;
        }

        return "";
    }

    /*
     * =========================================================
     * TELEFONE
     * =========================================================
     */

    public String getTelefoneFormatado() {

        if (contribuinte == null) {
            return "";
        }

        String ddd =
                contribuinte.getDddTelefone();

        String telefone =
                contribuinte.getNumeroTelefone();

        if (ddd == null
                || telefone == null) {

            return "";
        }

        if (telefone.length() == 9) {

            return "("
                    + ddd
                    + ") "
                    + telefone.substring(0, 5)
                    + "-"
                    + telefone.substring(5);
        }

        if (telefone.length() == 8) {

            return "("
                    + ddd
                    + ") "
                    + telefone.substring(0, 4)
                    + "-"
                    + telefone.substring(4);
        }

        return "(" + ddd + ") " + telefone;
    }

    public String getDataAberturaFormatada() {

        if (contribuinte == null
                || contribuinte.getDataAbertura() == null) {

            return "";
        }

        return contribuinte
                .getDataAbertura()
                .format(FORMATADOR_DATA);
    }

    public String getEmailFormatado() {

        if (contribuinte == null
                || contribuinte.getEmailCorporativo() == null) {

            return "";
        }

        return contribuinte
                .getEmailCorporativo()
                .toLowerCase();
    }

    public String getCidadeUfFormatada() {

        if (contribuinte == null) {
            return "";
        }

        String cidade =
                contribuinte.getCidadeSede();

        String uf =
                contribuinte.getEstadoUf();

        if (cidade == null || cidade.isBlank()) {

            return uf == null ? "" : uf;
        }

        if (uf == null || uf.isBlank()) {

            return cidade;
        }

        return cidade + " - " + uf;
    }

    /*
     * =========================================================
     * FILTROS
     * =========================================================
     */

    public Long getFiltroNumeroRequisicao() {
        return filtroNumeroRequisicao;
    }

    public void setFiltroNumeroRequisicao(
            Long filtroNumeroRequisicao) {

        this.filtroNumeroRequisicao =
                filtroNumeroRequisicao;
    }

    public String getFiltroDocumento() {
        return filtroDocumento;
    }

    public void setFiltroDocumento(
            String filtroDocumento) {

        this.filtroDocumento =
                filtroDocumento;
    }

    public String getFiltroNome() {
        return filtroNome;
    }

    public void setFiltroNome(
            String filtroNome) {

        this.filtroNome =
                filtroNome;
    }

    /*
     * =========================================================
     * ORDENAÇÃO
     * =========================================================
     */

    public String getOrdenarPor() {
        return ordenarPor;
    }

    public String getDirecaoOrdenacao() {
        return direcaoOrdenacao;
    }

    public void ordenarPorRequisicao() {

        if ("REQUISICAO".equals(ordenarPor)) {

            direcaoOrdenacao =
                    "ASC".equals(direcaoOrdenacao)
                            ? "DESC"
                            : "ASC";

        } else {

            ordenarPor = "REQUISICAO";
            direcaoOrdenacao = "ASC";
        }

        paginaAtual = 1;

        pesquisar();
    }

    public void ordenarPorNome() {

        if ("NOME".equals(ordenarPor)) {

            direcaoOrdenacao =
                    "ASC".equals(direcaoOrdenacao)
                            ? "DESC"
                            : "ASC";

        } else {

            ordenarPor = "NOME";
            direcaoOrdenacao = "ASC";
        }

        paginaAtual = 1;

        pesquisar();
    }

    public void ordenarPorDocumento() {

        if ("DOCUMENTO".equals(ordenarPor)) {

            direcaoOrdenacao =
                    "ASC".equals(direcaoOrdenacao)
                            ? "DESC"
                            : "ASC";

        } else {

            ordenarPor = "DOCUMENTO";
            direcaoOrdenacao = "ASC";
        }

        paginaAtual = 1;

        pesquisar();
    }

    public String getIconeRequisicao() {

        if (!"REQUISICAO".equals(ordenarPor)) {
            return "↕";
        }

        return "ASC".equals(direcaoOrdenacao)
                ? "↑"
                : "↓";
    }

    public String getIconeNome() {

        if (!"NOME".equals(ordenarPor)) {
            return "↕";
        }

        return "ASC".equals(direcaoOrdenacao)
                ? "↑"
                : "↓";
    }

    public String getIconeDocumento() {

        if (!"DOCUMENTO".equals(ordenarPor)) {
            return "↕";
        }

        return "ASC".equals(direcaoOrdenacao)
                ? "↑"
                : "↓";
    }

    /*
     * =========================================================
     * VALIDAÇÃO DOS FILTROS
     * =========================================================
     */

    private boolean validarFiltrosPesquisa() {

        if (filtroNumeroRequisicao != null
                && filtroNumeroRequisicao < 0) {

            adicionarMensagemErro(
                    "Número da requisição inválido."
            );

            return false;
        }

        if (filtroDocumento != null
                && !filtroDocumento.isBlank()) {

            String documentoInformado =
                    filtroDocumento.trim();

            if (!documentoInformado.matches(
                    "^[0-9.\\-/\\s]+$")) {

                adicionarMensagemErro(
                        "Documento deve conter apenas números e caracteres de máscara de CPF/CNPJ."
                );

                return false;
            }

            String documentoNormalizado =
                    documentoInformado.replaceAll(
                            "\\D",
                            ""
                    );

            if (documentoNormalizado.isBlank()) {

                filtroDocumento = null;

            } else if (documentoNormalizado.length()
                    > DOCUMENTO_PESQUISA_MAXIMO) {

                adicionarMensagemErro(
                        "Documento deve conter no máximo 14 dígitos."
                );

                return false;

            } else {

                filtroDocumento =
                        documentoNormalizado;
            }

        } else {

            filtroDocumento = null;
        }

        if (filtroNome != null
                && !filtroNome.isBlank()) {

            filtroNome =
                    filtroNome.trim();

            if (filtroNome.length()
                    > NOME_PESQUISA_MAXIMO) {

                adicionarMensagemErro(
                        "Nome/Razão Social deve conter no máximo 120 caracteres."
                );

                return false;
            }

        } else {

            filtroNome = null;
        }

        if (paginaAtual < 1) {
            paginaAtual = 1;
        }

        if (!"REQUISICAO".equals(ordenarPor)
                && !"NOME".equals(ordenarPor)
                && !"DOCUMENTO".equals(ordenarPor)) {

            adicionarMensagemErro(
                    "Critério de ordenação inválido."
            );

            return false;
        }

        if (!"ASC".equals(direcaoOrdenacao)
                && !"DESC".equals(direcaoOrdenacao)) {

            adicionarMensagemErro(
                    "Direção de ordenação inválida."
            );

            return false;
        }

        return true;
    }

    /*
     * =========================================================
     * VALIDAÇÃO DA CHAVE DOCUMENTAL
     * =========================================================
     */

    private boolean validarChaveDocumento(
            String docCorpo,
            String docFilial,
            String docDigito) {

        if (docCorpo == null
                || docFilial == null
                || docDigito == null) {

            adicionarMensagemErro(
                    "Identificação do contribuinte inválida."
            );

            return false;
        }

        if (!docCorpo.matches("\\d+")
                || !docFilial.matches("\\d+")
                || !docDigito.matches("\\d+")) {

            adicionarMensagemErro(
                    "Identificação do contribuinte inválida."
            );

            return false;
        }

        if (docCorpo.length() == 9) {

            if (!"0000".equals(docFilial)
                    || docDigito.length() != 2) {

                adicionarMensagemErro(
                        "Chave de CPF inválida."
                );

                return false;
            }

            return true;
        }

        if (docCorpo.length() == 8) {

            if (docFilial.length() != 4
                    || docDigito.length() != 2) {

                adicionarMensagemErro(
                        "Chave de CNPJ inválida."
                );

                return false;
            }

            return true;
        }

        adicionarMensagemErro(
                "Identificação do contribuinte inválida."
        );

        return false;
    }

    /*
     * =========================================================
     * PAGINAÇÃO
     * =========================================================
     */

    public int getPaginaAtual() {
        return paginaAtual;
    }

    public long getTotalRegistros() {
        return totalRegistros;
    }

    public int getTotalPaginas() {
        return totalPaginas;
    }

    public int getRegistrosPorPagina() {
        return REGISTROS_POR_PAGINA;
    }

    public void listar() {

        paginaAtual = 1;

        carregarPagina();
    }

    public void pesquisar() {

        paginaAtual = 1;

        carregarPagina();
    }

    private void carregarPagina() {

        try {

            if (!validarFiltrosPesquisa()) {

                contribuintes =
                        new ArrayList<>();

                totalRegistros = 0;

                totalPaginas = 1;

                paginaAtual = 1;

                return;
            }

            String documentoNormalizado =
                    filtroDocumento == null
                            ? null
                            : filtroDocumento;

            String nomeNormalizado =
                    filtroNome == null
                            ? null
                            : filtroNome;

            if (documentoNormalizado != null
                    && documentoNormalizado.isBlank()) {

                documentoNormalizado = null;
            }

            if (nomeNormalizado != null
                    && nomeNormalizado.isBlank()) {

                nomeNormalizado = null;
            }

            totalRegistros =
                    repository.contar(
                            filtroNumeroRequisicao,
                            documentoNormalizado,
                            nomeNormalizado
                    );

            if (totalRegistros == 0) {

                totalPaginas = 1;

            } else {

                totalPaginas =
                        (int) Math.ceil(
                                (double) totalRegistros
                                        / REGISTROS_POR_PAGINA
                        );
            }

            if (paginaAtual > totalPaginas) {
                paginaAtual = totalPaginas;
            }

            if (paginaAtual < 1) {
                paginaAtual = 1;
            }

            int offset =
                    (paginaAtual - 1)
                            * REGISTROS_POR_PAGINA;

            contribuintes =
                    repository.pesquisar(
                            filtroNumeroRequisicao,
                            documentoNormalizado,
                            nomeNormalizado,
                            ordenarPor,
                            direcaoOrdenacao,
                            REGISTROS_POR_PAGINA,
                            offset
                    );

        } catch (Exception e) {

            System.err.println(
                    "ERRO AO CARREGAR PÁGINA DE CONTRIBUINTES!"
            );

            e.printStackTrace();

            adicionarMensagemErro(
                    "Não foi possível concluir a operação. Tente novamente."
            );
        }
    }

    public void primeiraPagina() {

        paginaAtual = 1;

        carregarPagina();
    }

    public void paginaAnterior() {

        if (paginaAtual > 1) {

            paginaAtual--;

            carregarPagina();
        }
    }

    public void proximaPagina() {

        if (paginaAtual < totalPaginas) {

            paginaAtual++;

            carregarPagina();
        }
    }

    public void ultimaPagina() {

        paginaAtual = totalPaginas;

        carregarPagina();
    }

    public boolean isNaPrimeiraPagina() {
        return paginaAtual <= 1;
    }

    public boolean isNaUltimaPagina() {
        return paginaAtual >= totalPaginas;
    }

    /*
     * =========================================================
     * CONSULTAR
     * =========================================================
     */

    public String consultar(
            String docCorpo,
            String docFilial,
            String docDigito) {

        try {

            if (!validarChaveDocumento(
                    docCorpo,
                    docFilial,
                    docDigito)) {

                return null;
            }

            Contribuinte resultado =
                    repository.detalhar(
                            docCorpo,
                            docFilial,
                            docDigito
                    );

            if (resultado == null) {

                adicionarMensagemErro(
                        "O contribuinte não foi localizado. "
                                + "Atualize a listagem e tente novamente."
                );

                return null;
            }

            FacesContext contexto =
                    FacesContext.getCurrentInstance();

            contexto.getExternalContext()
                    .getFlash()
                    .put(
                            FLASH_CONTRIBUINTE,
                            resultado
                    );

            salvarEstadoListaNoFlash();

            return "detalhar?faces-redirect=true";

        } catch (Exception e) {

            System.err.println(
                    "ERRO AO CONSULTAR CONTRIBUINTE!"
            );

            e.printStackTrace();

            adicionarMensagemErro(
                    "Não foi possível concluir a operação. Tente novamente."
            );

            return null;
        }
    }

    /*
     * =========================================================
     * ALTERAR
     * =========================================================
     */

    public String alterar(
            String docCorpo,
            String docFilial,
            String docDigito) {

        try {

            if (!validarChaveDocumento(
                    docCorpo,
                    docFilial,
                    docDigito)) {

                return null;
            }

            Contribuinte resultado =
                    repository.detalhar(
                            docCorpo,
                            docFilial,
                            docDigito
                    );

            if (resultado == null) {

                adicionarMensagemErro(
                        "O contribuinte não foi localizado. "
                                + "Atualize a listagem e tente novamente."
                );

                return null;
            }

            FacesContext contexto =
                    FacesContext.getCurrentInstance();

            contexto.getExternalContext()
                    .getFlash()
                    .put(
                            FLASH_CONTRIBUINTE,
                            resultado
                    );

            salvarEstadoListaNoFlash();

            return "alterar?faces-redirect=true";

        } catch (Exception e) {

            System.err.println(
                    "ERRO AO CARREGAR CONTRIBUINTE PARA ALTERAÇÃO!"
            );

            e.printStackTrace();

            adicionarMensagemErro(
                    "Não foi possível concluir a operação. Tente novamente."
            );

            return null;
        }
    }

    /*
     * =========================================================
     * EXCLUIR - PREPARAR CONFIRMAÇÃO
     * =========================================================
     */

    public String excluir(
            String tipoDocumento,
            String docCorpo,
            String docFilial,
            String docDigito) {

        try {

            String tipoNormalizado =
                    normalizarTipoDocumento(tipoDocumento);

            if (!"CPF".equals(tipoNormalizado)
                    && !"CNPJ".equals(tipoNormalizado)) {

                adicionarMensagemErro(
                        "Tipo de documento inválido."
                );

                return null;
            }

            if (docCorpo == null
                    || docFilial == null
                    || docDigito == null) {

                adicionarMensagemErro(
                        "Identificação do contribuinte inválida."
                );

                return null;
            }

            if (!docCorpo.matches("\\d+")
                    || !docFilial.matches("\\d+")
                    || !docDigito.matches("\\d+")) {

                adicionarMensagemErro(
                        "Identificação do contribuinte inválida."
                );

                return null;
            }

            if ("CPF".equals(tipoNormalizado)) {

                if (docCorpo.length() != 9
                        || !"0000".equals(docFilial)
                        || docDigito.length() != 2) {

                    adicionarMensagemErro(
                            "Chave de CPF inválida."
                    );

                    return null;
                }

            } else {

                if (docCorpo.length() != 8
                        || docFilial.length() != 4
                        || docDigito.length() != 2) {

                    adicionarMensagemErro(
                            "Chave de CNPJ inválida."
                    );

                    return null;
                }
            }

            Contribuinte resultado =
                    repository.detalhar(
                            docCorpo,
                            docFilial,
                            docDigito
                    );

            if (resultado == null) {

                adicionarMensagemErro(
                        "O contribuinte não foi localizado. "
                                + "Atualize a listagem e tente novamente."
                );

                return null;
            }

            if (!tipoNormalizado.equals(
                    resultado.getTipoDocumento())) {

                adicionarMensagemErro(
                        "Identificação do contribuinte inválida."
                );

                return null;
            }

            FacesContext contexto =
                    FacesContext.getCurrentInstance();

            contexto.getExternalContext()
                    .getFlash()
                    .put(
                            FLASH_CONTRIBUINTE_EXCLUSAO,
                            resultado
                    );

            salvarEstadoListaNoFlash();

            return "confirmarExclusao?faces-redirect=true";

        } catch (Exception e) {

            System.err.println(
                    "ERRO AO CARREGAR CONTRIBUINTE PARA EXCLUSÃO!"
            );

            e.printStackTrace();

            adicionarMensagemErro(
                    "Não foi possível concluir a operação. Tente novamente."
            );

            return null;
        }
    }

    /*
     * =========================================================
     * CONFIRMAR EXCLUSÃO
     * =========================================================
     */

    public String confirmarExclusao() {

        try {

            if (contribuinte == null
                    || contribuinte.getDocCorpo() == null
                    || contribuinte.getDocFilial() == null
                    || contribuinte.getDocDigito() == null) {

                FacesContext contexto =
                        FacesContext.getCurrentInstance();

                contexto.getExternalContext()
                        .getFlash()
                        .setKeepMessages(true);

                adicionarMensagemErro(
                        "Não foi possível identificar o contribuinte para exclusão."
                );

                return voltarParaLista();
            }

            Contribuinte existente =
                    repository.detalhar(
                            contribuinte.getDocCorpo(),
                            contribuinte.getDocFilial(),
                            contribuinte.getDocDigito()
                    );

            if (existente == null) {

                FacesContext contexto =
                        FacesContext.getCurrentInstance();

                contexto.getExternalContext()
                        .getFlash()
                        .setKeepMessages(true);

                adicionarMensagemErro(
                        "O contribuinte não foi localizado. "
                                + "Atualize a listagem e tente novamente."
                );

                return voltarParaLista();
            }

            repository.excluir(
                    existente.getDocCorpo(),
                    existente.getDocFilial(),
                    existente.getDocDigito()
            );

            FacesContext contexto =
                    FacesContext.getCurrentInstance();

            contexto.getExternalContext()
                    .getFlash()
                    .setKeepMessages(true);

            adicionarMensagemSucesso(
                    "Contribuinte excluído com sucesso."
            );

            return voltarParaLista();

        } catch (Exception e) {

            System.err.println(
                    "ERRO AO EXCLUIR CONTRIBUINTE!"
            );

            e.printStackTrace();

            adicionarMensagemErro(
                    "Não foi possível concluir a operação. Tente novamente."
            );

            return null;
        }
    }

    /*
     * =========================================================
     * RESTAURAR ALTERAÇÃO
     * =========================================================
     */

    public void restaurarAlteracao() {

        if (contribuinteOriginal == null) {
            return;
        }

        contribuinte.setQuantidadeFuncionarios(
                contribuinteOriginal.getQuantidadeFuncionarios()
        );

        contribuinte.setFaturamentoAnual(
                contribuinteOriginal.getFaturamentoAnual()
        );

        contribuinte.setDataAbertura(
                contribuinteOriginal.getDataAbertura()
        );

        contribuinte.setRazaoSocialNome(
                contribuinteOriginal.getRazaoSocialNome()
        );

        contribuinte.setNomeFantasia(
                contribuinteOriginal.getNomeFantasia()
        );

        contribuinte.setDddTelefone(
                contribuinteOriginal.getDddTelefone()
        );

        contribuinte.setNumeroTelefone(
                contribuinteOriginal.getNumeroTelefone()
        );

        contribuinte.setEmailCorporativo(
                contribuinteOriginal.getEmailCorporativo()
        );

        contribuinte.setCidadeSede(
                contribuinteOriginal.getCidadeSede()
        );

        contribuinte.setEstadoUf(
                contribuinteOriginal.getEstadoUf()
        );

        if (contribuinteOriginal.getEstadoUf() != null
                && !contribuinteOriginal.getEstadoUf().isBlank()) {

            municipios =
                    municipioService.buscarMunicipiosPorUf(
                            contribuinteOriginal.getEstadoUf()
                    );

        } else {

            municipios =
                    new ArrayList<>();
        }
    }

    /*
     * =========================================================
     * VALIDAÇÃO DO NOME / RAZÃO SOCIAL
     * =========================================================
     */

    private boolean validarNomeRazaoSocial(
            String nome) {

        if (nome == null
                || nome.isBlank()) {

            adicionarMensagemErro(
                    "Informe o campo Nome/Razão Social."
            );

            return false;
        }

        String nomeNormalizado =
                nome.trim();

        if (nomeNormalizado.length() < NOME_MINIMO
                || nomeNormalizado.length() > NOME_MAXIMO) {

            adicionarMensagemErro(
                    "O campo Nome/Razão Social está em formato inválido."
            );

            return false;
        }

        /*
         * Permite:
         * - letras, inclusive acentuadas;
         * - marcas Unicode;
         * - espaços;
         * - apóstrofo;
         * - ponto;
         * - hífen;
         * - &, / e parênteses, comuns em razões sociais.
         *
         * Não permite números.
         */
        if (!nomeNormalizado.matches(
                "^[\\p{L}\\p{M} .,'&/()\\-]+$")) {

            adicionarMensagemErro(
                    "O campo Nome/Razão Social está em formato inválido."
            );

            return false;
        }

        return true;
    }

    /*
     * =========================================================
     * VALIDAÇÃO DA UF
     * =========================================================
     */

    private boolean validarUf(
            String uf) {

        if (uf == null
                || uf.isBlank()) {

            adicionarMensagemErro(
                    "Informe o campo UF."
            );

            return false;
        }

        String ufNormalizada =
                uf.trim().toUpperCase();

        if (!ufNormalizada.matches("[A-Z]{2}")
                || !UFS_VALIDAS.contains(
                ufNormalizada)) {

            adicionarMensagemErro(
                    "O campo UF está em formato inválido."
            );

            return false;
        }

        return true;
    }

    /*
     * =========================================================
     * VALIDAÇÃO DOS CARACTERES DA CIDADE
     * =========================================================
     */

    private boolean validarCidadeCaracteres(
            String cidade) {

        if (cidade == null
                || cidade.isBlank()) {

            adicionarMensagemErro(
                    "Informe o campo Cidade."
            );

            return false;
        }

        String cidadeNormalizada =
                cidade.trim();

        if (cidadeNormalizada.length()
                > CIDADE_MAXIMO) {

            adicionarMensagemErro(
                    "O campo Cidade está em formato inválido."
            );

            return false;
        }

        /*
         * Cidade:
         * - letras e acentos;
         * - espaços;
         * - apóstrofo;
         * - hífen.
         *
         * Números e demais símbolos não são permitidos.
         */
        if (!cidadeNormalizada.matches(
                "^[\\p{L}\\p{M} .'-]+$")) {

            adicionarMensagemErro(
                    "O campo Cidade está em formato inválido."
            );

            return false;
        }

        return true;
    }

    /*
     * =========================================================
     * VALIDAÇÃO DOS CAMPOS EDITÁVEIS
     * =========================================================
     */

    private boolean validarCamposEditaveis() {

        boolean possuiErros = false;

        /*
         * Tipo
         */
        String tipo =
                contribuinte.getTipoDocumento();

        if (!"CPF".equals(tipo)
                && !"CNPJ".equals(tipo)) {

            adicionarMensagemErro(
                    "O campo Tipo de documento está em formato inválido."
            );

            possuiErros = true;
        }

        /*
         * CPF / CNPJ
         */
        if ("CPF".equals(tipo)) {

            if (contribuinte.getDocCorpo() == null
                    || !contribuinte.getDocCorpo()
                    .matches("\\d{9}")
                    || !"0000".equals(
                    contribuinte.getDocFilial())
                    || contribuinte.getDocDigito() == null
                    || !contribuinte.getDocDigito()
                    .matches("\\d{2}")) {

                adicionarMensagemErro(
                        "O campo Documento está em formato inválido."
                );

                possuiErros = true;
            }

            contribuinte.setQuantidadeFuncionarios(0);
            contribuinte.setNomeFantasia(null);

        } else if ("CNPJ".equals(tipo)) {

            if (contribuinte.getDocCorpo() == null
                    || !contribuinte.getDocCorpo()
                    .matches("\\d{8}")
                    || contribuinte.getDocFilial() == null
                    || !contribuinte.getDocFilial()
                    .matches("\\d{4}")
                    || contribuinte.getDocDigito() == null
                    || !contribuinte.getDocDigito()
                    .matches("\\d{2}")) {

                adicionarMensagemErro(
                        "O campo Documento está em formato inválido."
                );

                possuiErros = true;
            }

            long quantidade =
                    contribuinte.getQuantidadeFuncionarios();

            if (quantidade < 0
                    || quantidade >
                    QUANTIDADE_FUNCIONARIOS_MAXIMA) {

                adicionarMensagemErro(
                        "O campo Quantidade de funcionários está em formato inválido."
                );

                possuiErros = true;
            }

        } else {

            possuiErros = true;
        }

        /*
         * Nome / Razão Social
         */
        String nome =
                contribuinte.getRazaoSocialNome();

        if (!validarNomeRazaoSocial(nome)) {

            possuiErros = true;

        } else {

            contribuinte.setRazaoSocialNome(
                    nome.trim()
            );
        }

        /*
         * Nome fantasia
         */
        if ("CNPJ".equals(tipo)) {

            String nomeFantasia =
                    contribuinte.getNomeFantasia();

            if (nomeFantasia != null) {

                nomeFantasia =
                        nomeFantasia.trim();

                if (nomeFantasia.isBlank()) {

                    contribuinte.setNomeFantasia(null);

                } else if (nomeFantasia.length()
                        > NOME_FANTASIA_MAXIMO) {

                    adicionarMensagemErro(
                            "O campo Nome fantasia está em formato inválido."
                    );

                    possuiErros = true;

                } else if (!nomeFantasia.matches(
                        "^[\\p{L}\\p{M}0-9 .,'&/()\\-]+$")) {

                    adicionarMensagemErro(
                            "O campo Nome fantasia está em formato inválido."
                    );

                    possuiErros = true;

                } else {

                    contribuinte.setNomeFantasia(
                            nomeFantasia
                    );
                }
            }
        }

        /*
         * E-mail
         */
        String email =
                contribuinte.getEmailCorporativo();

        if (email == null
                || email.isBlank()) {

            adicionarMensagemErro(
                    "Informe o campo E-mail corporativo."
            );

            possuiErros = true;

        } else {

            email =
                    email.trim();

            String regexEmail =
                    "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

            if (email.length() > EMAIL_MAXIMO
                    || !email.matches(regexEmail)) {

                adicionarMensagemErro(
                        "O campo E-mail corporativo está em formato inválido."
                );

                possuiErros = true;

            } else {

                contribuinte.setEmailCorporativo(
                        email.toLowerCase()
                );
            }
        }

        /*
         * DDD
         */
        String ddd =
                contribuinte.getDddTelefone();

        if (ddd == null
                || !ddd.matches("\\d{2}")
                || !DDDS_VALIDOS.contains(ddd)) {

            adicionarMensagemErro(
                    "O campo DDD está em formato inválido."
            );

            possuiErros = true;
        }

        /*
         * Telefone
         */
        String telefone =
                contribuinte.getNumeroTelefone();

        if (telefone == null
                || !telefone.matches("\\d{8,9}")
                || (telefone.length() == 9
                && !telefone.startsWith("9"))) {

            adicionarMensagemErro(
                    "O campo Telefone está em formato inválido."
            );

            possuiErros = true;
        }

        /*
         * Data
         */
        LocalDate data =
                contribuinte.getDataAbertura();

        if (data == null) {

            adicionarMensagemErro(
                    "Informe o campo Data de abertura."
            );

            possuiErros = true;

        } else if (data.isAfter(LocalDate.now())) {

            adicionarMensagemErro(
                    "O campo Data de abertura está em formato inválido."
            );

            possuiErros = true;
        }

        /*
         * Faturamento
         */
        BigDecimal faturamento =
                contribuinte.getFaturamentoAnual();

        if (faturamento == null
                || faturamento.compareTo(
                BigDecimal.ZERO) < 0
                || faturamento.scale() > 2
                || faturamento.compareTo(
                FATURAMENTO_MAXIMO) > 0) {

            adicionarMensagemErro(
                    "O campo Faturamento anual está em formato inválido."
            );

            possuiErros = true;
        }

        /*
         * UF
         */
        String uf =
                contribuinte.getEstadoUf();

        if (!validarUf(uf)) {

            possuiErros = true;

        } else {

            uf =
                    uf.trim().toUpperCase();

            contribuinte.setEstadoUf(uf);
        }

        /*
         * Cidade
         */
        String cidade =
                contribuinte.getCidadeSede();

        if (!validarCidadeCaracteres(cidade)) {

            possuiErros = true;

        } else {

            cidade =
                    cidade.trim();

            if (uf == null
                    || uf.isBlank()) {

                possuiErros = true;

            } else {

                List<String> municipiosDaUf =
                        municipioService.buscarMunicipiosPorUf(uf);

                if (!municipiosDaUf.contains(cidade)) {

                    adicionarMensagemErro(
                            "A cidade informada não pertence à UF selecionada."
                    );

                    possuiErros = true;

                } else {

                    contribuinte.setCidadeSede(cidade);
                }
            }
        }

        return !possuiErros;
    }

    /*
     * =========================================================
     * SALVAR ALTERAÇÃO
     * =========================================================
     */

    public String salvarAlteracao() {

        try {

            Contribuinte existente =
                    repository.detalhar(
                            contribuinte.getDocCorpo(),
                            contribuinte.getDocFilial(),
                            contribuinte.getDocDigito()
                    );

            if (existente == null) {

                FacesContext contexto =
                        FacesContext.getCurrentInstance();

                contexto.getExternalContext()
                        .getFlash()
                        .setKeepMessages(true);

                adicionarMensagemErro(
                        "O contribuinte não foi localizado. "
                                + "Atualize a listagem e tente novamente."
                );

                return voltarParaLista();
            }

            if (!validarCamposEditaveis()) {
                return null;
            }

            repository.alterar(
                    existente.getDocCorpo(),
                    existente.getDocFilial(),
                    existente.getDocDigito(),
                    existente.getTipoDocumento(),
                    contribuinte.getQuantidadeFuncionarios(),
                    contribuinte.getFaturamentoAnual(),
                    contribuinte.getDataAbertura(),
                    contribuinte.getRazaoSocialNome(),
                    contribuinte.getNomeFantasia(),
                    contribuinte.getDddTelefone(),
                    contribuinte.getNumeroTelefone(),
                    contribuinte.getEmailCorporativo(),
                    contribuinte.getCidadeSede(),
                    contribuinte.getEstadoUf()
            );

            FacesContext contexto =
                    FacesContext.getCurrentInstance();

            contexto.getExternalContext()
                    .getFlash()
                    .setKeepMessages(true);

            adicionarMensagemSucesso(
                    "Contribuinte alterado com sucesso."
            );

            salvarEstadoListaNoFlash();

            return "lista?faces-redirect=true";

        } catch (Exception e) {

            System.err.println(
                    "ERRO AO SALVAR ALTERAÇÃO DO CONTRIBUINTE!"
            );

            e.printStackTrace();

            adicionarMensagemErro(
                    "Não foi possível concluir a operação. Tente novamente."
            );

            return null;
        }
    }

    /*
     * =========================================================
     * VOLTAR PARA LISTA
     * =========================================================
     */

    public String voltarParaLista() {

        salvarEstadoListaNoFlash();

        return "lista?faces-redirect=true";
    }

    /*
     * =========================================================
     * LIMPAR PESQUISA
     * =========================================================
     */

    public String limparPesquisa() {

        filtroNumeroRequisicao = null;

        filtroDocumento = null;

        filtroNome = null;

        paginaAtual = 1;

        ordenarPor = "REQUISICAO";

        direcaoOrdenacao = "ASC";

        salvarEstadoListaNoFlash();

        return "lista?faces-redirect=true";
    }

    /*
     * =========================================================
     * MUNICÍPIOS
     * =========================================================
     */

    public void carregarMunicipios() {

        String uf =
                contribuinte.getEstadoUf();

        if (uf == null
                || uf.isBlank()
                || !UFS_VALIDAS.contains(
                uf.trim().toUpperCase())) {

            municipios =
                    new ArrayList<>();

            contribuinte.setCidadeSede(null);

            return;
        }

        uf =
                uf.trim().toUpperCase();

        contribuinte.setEstadoUf(uf);

        municipios =
                municipioService.buscarMunicipiosPorUf(uf);

        contribuinte.setCidadeSede(null);
    }

    public void carregarMunicipiosParaAlteracao() {

        String uf =
                contribuinte.getEstadoUf();

        if (uf == null
                || uf.isBlank()) {

            municipios =
                    new ArrayList<>();

            return;
        }

        uf =
                uf.trim().toUpperCase();

        if (!UFS_VALIDAS.contains(uf)) {

            municipios =
                    new ArrayList<>();

            return;
        }

        municipios =
                municipioService.buscarMunicipiosPorUf(uf);
    }

    /*
     * =========================================================
     * MENSAGENS
     * =========================================================
     */

    private void adicionarMensagemErro(
            String mensagem) {

        FacesContext.getCurrentInstance().addMessage(
                null,
                new FacesMessage(
                        FacesMessage.SEVERITY_ERROR,
                        mensagem,
                        null
                )
        );
    }

    private void adicionarMensagemSucesso(
            String mensagem) {

        FacesContext.getCurrentInstance().addMessage(
                null,
                new FacesMessage(
                        FacesMessage.SEVERITY_INFO,
                        mensagem,
                        null
                )
        );
    }

    /*
     * =========================================================
     * DOCUMENTO DUPLICADO
     * =========================================================
     */

    private boolean isDocumentoDuplicado(
            Throwable excecao) {

        Throwable atual =
                excecao;

        while (atual != null) {

            String sqlState = null;

            if (atual instanceof java.sql.SQLException) {

                sqlState =
                        ((java.sql.SQLException) atual)
                                .getSQLState();
            }

            String mensagem =
                    atual.getMessage();

            if ("23000".equals(sqlState)) {
                return true;
            }

            if (mensagem != null) {

                String mensagemNormalizada =
                        mensagem.toLowerCase();

                if (mensagemNormalizada.contains(
                        "duplicate entry")) {

                    return true;
                }

                if (mensagemNormalizada.contains(
                        "duplicate key")) {

                    return true;
                }
            }

            atual =
                    atual.getCause();
        }

        return false;
    }

    /*
     * =========================================================
     * INCLUIR
     * =========================================================
     */

    public void incluir() {

        try {

            boolean possuiErros = false;

            /*
             * =================================================
             * TIPO DE DOCUMENTO
             * =================================================
             */

            String tipo =
                    contribuinte.getTipoDocumento();

            if (!"CPF".equals(tipo)
                    && !"CNPJ".equals(tipo)) {

                adicionarMensagemErro(
                        "Informe o campo Tipo de documento."
                );

                possuiErros = true;
            }

            /*
             * =================================================
             * DOCUMENTO
             * =================================================
             */

            String documentoNormalizado =
                    documento == null
                            ? ""
                            : documento.replaceAll(
                            "\\D",
                            ""
                    );

            if ("CPF".equals(tipo)) {

                if (documentoNormalizado.length() != 11) {

                    adicionarMensagemErro(
                            "O campo CPF está em formato inválido."
                    );

                    possuiErros = true;

                } else {

                    contribuinte.setDocCorpo(
                            documentoNormalizado.substring(0, 9)
                    );

                    contribuinte.setDocFilial("0000");

                    contribuinte.setDocDigito(
                            documentoNormalizado.substring(9, 11)
                    );

                    contribuinte.setQuantidadeFuncionarios(0);

                    contribuinte.setNomeFantasia(null);
                }

            } else if ("CNPJ".equals(tipo)) {

                if (documentoNormalizado.length() != 14) {

                    adicionarMensagemErro(
                            "O campo CNPJ está em formato inválido."
                    );

                    possuiErros = true;

                } else {

                    contribuinte.setDocCorpo(
                            documentoNormalizado.substring(0, 8)
                    );

                    contribuinte.setDocFilial(
                            documentoNormalizado.substring(8, 12)
                    );

                    contribuinte.setDocDigito(
                            documentoNormalizado.substring(12, 14)
                    );
                }
            }

            /*
             * =================================================
             * FUNCIONÁRIOS
             * =================================================
             */

            if ("CNPJ".equals(tipo)) {

                long quantidade =
                        contribuinte.getQuantidadeFuncionarios();

                if (quantidade < 0
                        || quantidade >
                        QUANTIDADE_FUNCIONARIOS_MAXIMA) {

                    adicionarMensagemErro(
                            "O campo Quantidade de funcionários está em formato inválido."
                    );

                    possuiErros = true;
                }

            } else if ("CPF".equals(tipo)) {

                contribuinte.setQuantidadeFuncionarios(0);
            }

            /*
             * =================================================
             * NOME / RAZÃO SOCIAL
             * =================================================
             */

            String nome =
                    contribuinte.getRazaoSocialNome();

            if (!validarNomeRazaoSocial(nome)) {

                possuiErros = true;

            } else {

                contribuinte.setRazaoSocialNome(
                        nome.trim()
                );
            }

            /*
             * =================================================
             * NOME FANTASIA
             * =================================================
             */

            if ("CNPJ".equals(tipo)) {

                String nomeFantasia =
                        contribuinte.getNomeFantasia();

                if (nomeFantasia != null) {

                    nomeFantasia =
                            nomeFantasia.trim();

                    if (nomeFantasia.isBlank()) {

                        contribuinte.setNomeFantasia(null);

                    } else if (nomeFantasia.length()
                            > NOME_FANTASIA_MAXIMO) {

                        adicionarMensagemErro(
                                "O campo Nome fantasia está em formato inválido."
                        );

                        possuiErros = true;

                    } else if (!nomeFantasia.matches(
                            "^[\\p{L}\\p{M}0-9 .,'&/()\\-]+$")) {

                        adicionarMensagemErro(
                                "O campo Nome fantasia está em formato inválido."
                        );

                        possuiErros = true;

                    } else {

                        contribuinte.setNomeFantasia(
                                nomeFantasia
                        );
                    }
                }
            }

            /*
             * =================================================
             * E-MAIL
             * =================================================
             */

            String email =
                    contribuinte.getEmailCorporativo();

            if (email == null
                    || email.isBlank()) {

                adicionarMensagemErro(
                        "Informe o campo E-mail corporativo."
                );

                possuiErros = true;

            } else {

                email =
                        email.trim();

                String regexEmail =
                        "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

                if (email.length() > EMAIL_MAXIMO
                        || !email.matches(regexEmail)) {

                    adicionarMensagemErro(
                            "O campo E-mail corporativo está em formato inválido."
                    );

                    possuiErros = true;

                } else {

                    contribuinte.setEmailCorporativo(
                            email.toLowerCase()
                    );
                }
            }

            /*
             * =================================================
             * DDD
             * =================================================
             */

            String ddd =
                    contribuinte.getDddTelefone();

            if (ddd == null
                    || !ddd.matches("\\d{2}")
                    || !DDDS_VALIDOS.contains(ddd)) {

                adicionarMensagemErro(
                        "O campo DDD está em formato inválido."
                );

                possuiErros = true;
            }

            /*
             * =================================================
             * TELEFONE
             * =================================================
             */

            String telefone =
                    contribuinte.getNumeroTelefone();

            if (telefone == null
                    || !telefone.matches("\\d{8,9}")
                    || (telefone.length() == 9
                    && !telefone.startsWith("9"))) {

                adicionarMensagemErro(
                        "O campo Telefone está em formato inválido."
                );

                possuiErros = true;
            }

            /*
             * =================================================
             * DATA
             * =================================================
             */

            LocalDate data =
                    contribuinte.getDataAbertura();

            if (data == null) {

                adicionarMensagemErro(
                        "Informe o campo Data de abertura."
                );

                possuiErros = true;

            } else if (data.isAfter(LocalDate.now())) {

                adicionarMensagemErro(
                        "O campo Data de abertura está em formato inválido."
                );

                possuiErros = true;
            }

            /*
             * =================================================
             * FATURAMENTO
             * =================================================
             */

            BigDecimal faturamento =
                    contribuinte.getFaturamentoAnual();

            if (faturamento == null
                    || faturamento.compareTo(
                    BigDecimal.ZERO) < 0
                    || faturamento.scale() > 2
                    || faturamento.compareTo(
                    FATURAMENTO_MAXIMO) > 0) {

                adicionarMensagemErro(
                        "O campo Faturamento anual está em formato inválido."
                );

                possuiErros = true;
            }

            /*
             * =================================================
             * UF
             * =================================================
             */

            String uf =
                    contribuinte.getEstadoUf();

            if (!validarUf(uf)) {

                possuiErros = true;

            } else {

                uf =
                        uf.trim().toUpperCase();

                contribuinte.setEstadoUf(uf);
            }

            /*
             * =================================================
             * CIDADE
             * =================================================
             */

            String cidade =
                    contribuinte.getCidadeSede();

            if (!validarCidadeCaracteres(cidade)) {

                possuiErros = true;

            } else {

                cidade =
                        cidade.trim();

                if (uf == null
                        || uf.isBlank()) {

                    possuiErros = true;

                } else {

                    List<String> municipiosDaUf =
                            municipioService.buscarMunicipiosPorUf(uf);

                    if (!municipiosDaUf.contains(cidade)) {

                        adicionarMensagemErro(
                                "A cidade informada não pertence à UF selecionada."
                        );

                        possuiErros = true;

                    } else {

                        contribuinte.setCidadeSede(cidade);
                    }
                }
            }

            /*
             * =================================================
             * NÃO PERSISTE SE HOUVER ERROS
             * =================================================
             */

            if (possuiErros) {
                return;
            }

            /*
             * =================================================
             * INCLUSÃO NO BANCO
             * =================================================
             */

            repository.incluir(
                    contribuinte.getDocCorpo(),
                    contribuinte.getDocFilial(),
                    contribuinte.getDocDigito(),
                    contribuinte.getTipoDocumento(),
                    contribuinte.getQuantidadeFuncionarios(),
                    contribuinte.getFaturamentoAnual(),
                    contribuinte.getDataAbertura(),
                    contribuinte.getRazaoSocialNome(),
                    contribuinte.getNomeFantasia(),
                    contribuinte.getDddTelefone(),
                    contribuinte.getNumeroTelefone(),
                    contribuinte.getEmailCorporativo(),
                    contribuinte.getCidadeSede(),
                    contribuinte.getEstadoUf()
            );

            adicionarMensagemSucesso(
                    "Contribuinte incluído com sucesso."
            );

        } catch (Exception e) {

            System.err.println(
                    "ERRO AO INCLUIR CONTRIBUINTE!"
            );

            e.printStackTrace();

            if (isDocumentoDuplicado(e)) {

                adicionarMensagemErro(
                        "Já existe um contribuinte cadastrado com este documento."
                );

            } else {

                adicionarMensagemErro(
                        "Não foi possível concluir a operação. Tente novamente."
                );
            }
        }
    }
}
