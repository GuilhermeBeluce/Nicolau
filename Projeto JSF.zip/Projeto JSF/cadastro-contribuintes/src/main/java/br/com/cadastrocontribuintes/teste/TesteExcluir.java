package br.com.cadastrocontribuintes.teste;

import br.com.cadastrocontribuintes.repository.ContribuinteRepository;

public class TesteExcluir {

    public static void main(String[] args) {

        ContribuinteRepository repository = new ContribuinteRepository();

        try {

            repository.excluir(
                    "123456789",
                    "0000",
                    "09"
            );

            System.out.println("=================================");
            System.out.println("EXCLUSÃO REALIZADA COM SUCESSO!");
            System.out.println("=================================");
            System.out.println("Documento excluído: 123456789000009");
            System.out.println("=================================");

        } catch (Exception e) {

            System.err.println("=================================");
            System.err.println("ERRO AO EXCLUIR CONTRIBUINTE!");
            System.err.println("=================================");

            e.printStackTrace();
        }
    }
}