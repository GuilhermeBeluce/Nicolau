package br.com.cadastrocontribuintes.teste;

import br.com.cadastrocontribuintes.repository.ContribuinteRepository;

import java.math.BigDecimal;
import java.time.LocalDate;

public class TesteInclusao {

    public static void main(String[] args) {

        ContribuinteRepository repository = new ContribuinteRepository();

        try {

            repository.incluir(
                    "123456789",
                    "0000",
                    "09",
                    "CPF",
                    0,
                    new BigDecimal("75000.00"),
                    LocalDate.of(1990, 5, 15),
                    "João da Silva",
                    null,
                    "47",
                    "988888888",
                    "joao.silva.novo@empresa.com.br",
                    "Joinville",
                    "SC"
            );

            System.out.println("=================================");
            System.out.println("INCLUSÃO REALIZADA COM SUCESSO!");
            System.out.println("Contribuinte: João da Silva");
            System.out.println("=================================");

        } catch (Exception e) {

            System.err.println("=================================");
            System.err.println("ERRO AO INCLUIR CONTRIBUINTE!");
            System.err.println("=================================");

            e.printStackTrace();
        }
    }
}