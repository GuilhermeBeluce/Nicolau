USE cadastro_contribuintes;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_incluir(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2),
    IN p_tipo_documento ENUM('CPF', 'CNPJ'),
    IN p_quantidade_funcionarios INT UNSIGNED,
    IN p_faturamento_anual DECIMAL(15,2),
    IN p_data_abertura DATE,
    IN p_razao_social_nome VARCHAR(120),
    IN p_nome_fantasia VARCHAR(80),
    IN p_ddd_telefone CHAR(2),
    IN p_numero_telefone VARCHAR(9),
    IN p_email_corporativo VARCHAR(100),
    IN p_cidade_sede VARCHAR(60),
    IN p_estado_uf CHAR(2)
)
BEGIN

    /*
     * =========================================================
     * NORMALIZAÇÃO
     * =========================================================
     */

    SET p_doc_corpo = TRIM(p_doc_corpo);
    SET p_doc_filial = TRIM(p_doc_filial);
    SET p_doc_digito = TRIM(p_doc_digito);
    SET p_razao_social_nome = TRIM(p_razao_social_nome);
    SET p_nome_fantasia = NULLIF(TRIM(p_nome_fantasia), '');
    SET p_ddd_telefone = TRIM(p_ddd_telefone);
    SET p_numero_telefone = TRIM(p_numero_telefone);
    SET p_email_corporativo = LOWER(TRIM(p_email_corporativo));
    SET p_cidade_sede = TRIM(p_cidade_sede);
    SET p_estado_uf = UPPER(TRIM(p_estado_uf));


    /*
     * =========================================================
     * TIPO DO DOCUMENTO
     * =========================================================
     */

    IF p_tipo_documento IS NULL
       OR p_tipo_documento NOT IN ('CPF', 'CNPJ') THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Tipo de documento está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * DOCUMENTO
     * =========================================================
     */

    IF p_tipo_documento = 'CPF' THEN

        /*
         * CPF:
         * 9 dígitos + filial 0000 + 2 dígitos
         */

        IF p_doc_corpo IS NULL
           OR p_doc_corpo NOT REGEXP '^[0-9]{9}$'
           OR p_doc_filial <> '0000'
           OR p_doc_digito IS NULL
           OR p_doc_digito NOT REGEXP '^[0-9]{2}$' THEN

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT =
                    'O campo Documento está em formato inválido.';

        END IF;

        /*
         * CPF não possui nome fantasia
         * nem quantidade de funcionários.
         */

        SET p_nome_fantasia = NULL;
        SET p_quantidade_funcionarios = 0;

    ELSE

        /*
         * CNPJ:
         * 8 dígitos + 4 dígitos + 2 dígitos
         */

        IF p_doc_corpo IS NULL
           OR p_doc_corpo NOT REGEXP '^[0-9]{8}$'
           OR p_doc_filial IS NULL
           OR p_doc_filial NOT REGEXP '^[0-9]{4}$'
           OR p_doc_digito IS NULL
           OR p_doc_digito NOT REGEXP '^[0-9]{2}$' THEN

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT =
                    'O campo Documento está em formato inválido.';

        END IF;

    END IF;


    /*
     * =========================================================
     * NOME / RAZÃO SOCIAL
     * =========================================================
     */

    IF p_razao_social_nome IS NULL
       OR p_razao_social_nome = ''
       OR CHAR_LENGTH(p_razao_social_nome) < 3
       OR CHAR_LENGTH(p_razao_social_nome) > 120 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Nome/Razão social está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * NOME FANTASIA
     * =========================================================
     */

    IF p_tipo_documento = 'CNPJ'
       AND p_nome_fantasia IS NOT NULL
       AND CHAR_LENGTH(p_nome_fantasia) > 80 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Nome fantasia está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * FATURAMENTO
     * =========================================================
     */

    IF p_faturamento_anual IS NULL
       OR p_faturamento_anual < 0
       OR p_faturamento_anual > 9999999999999.99 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Faturamento anual está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * DATA DE ABERTURA
     * =========================================================
     */

    IF p_data_abertura IS NULL THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Informe o campo Data de abertura.';

    END IF;


    IF p_data_abertura > CURRENT_DATE() THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Data de abertura está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * DDD
     * =========================================================
     */

    IF p_ddd_telefone IS NULL
       OR p_ddd_telefone NOT REGEXP '^[0-9]{2}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo DDD está em formato inválido.';

    END IF;


    IF p_ddd_telefone NOT IN (
        '11','12','13','14','15','16','17','18','19',
        '21','22','24','27','28',
        '31','32','33','34','35','37','38',
        '41','42','43','44','45','46','47','48','49',
        '51','53','54','55',
        '61','62','63','64','65','66','67','68','69',
        '71','73','74','75','77','79',
        '81','82','83','84','85','86','87','88','89',
        '91','92','93','94','95','96','97','98','99'
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo DDD está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * TELEFONE
     * =========================================================
     */

    IF p_numero_telefone IS NULL
       OR p_numero_telefone NOT REGEXP '^[0-9]{8,9}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Telefone está em formato inválido.';

    END IF;


    IF CHAR_LENGTH(p_numero_telefone) = 9
       AND LEFT(p_numero_telefone, 1) <> '9' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Telefone está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * E-MAIL
     * =========================================================
     */

    IF p_email_corporativo IS NULL
       OR p_email_corporativo = ''
       OR CHAR_LENGTH(p_email_corporativo) > 100
       OR p_email_corporativo NOT REGEXP
          '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo E-mail corporativo está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * CIDADE
     * =========================================================
     */

    IF p_cidade_sede IS NULL
       OR p_cidade_sede = ''
       OR CHAR_LENGTH(p_cidade_sede) > 60
       OR p_cidade_sede REGEXP '[0-9]' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Cidade está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * UF
     * =========================================================
     */

    IF p_estado_uf NOT IN (
        'AC','AL','AP','AM','BA','CE','DF','ES','GO',
        'MA','MT','MS','MG','PA','PB','PR','PE','PI',
        'RJ','RN','RS','RO','RR','SC','SE','SP','TO'
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo UF está em formato inválido.';

    END IF;


    /*
     * =========================================================
     * DUPLICIDADE
     * =========================================================
     */

    IF EXISTS (
        SELECT 1
        FROM cadastro_contribuintes
        WHERE doc_corpo = p_doc_corpo
          AND doc_filial = p_doc_filial
          AND doc_digito = p_doc_digito
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Já existe um contribuinte cadastrado com este documento.';

    END IF;


    /*
     * =========================================================
     * INCLUSÃO
     * =========================================================
     */

    INSERT INTO cadastro_contribuintes (
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf
    )
    VALUES (
        p_doc_corpo,
        p_doc_filial,
        p_doc_digito,
        p_tipo_documento,
        p_quantidade_funcionarios,
        p_faturamento_anual,
        p_data_abertura,
        p_razao_social_nome,
        p_nome_fantasia,
        p_ddd_telefone,
        p_numero_telefone,
        p_email_corporativo,
        p_cidade_sede,
        p_estado_uf
    );

END$$

DELIMITER ;