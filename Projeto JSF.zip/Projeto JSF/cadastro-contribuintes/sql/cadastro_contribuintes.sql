CREATE DATABASE cadastro_contribuintes
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_0900_ai_ci;
    
    USE cadastro_contribuintes;
    
    CREATE TABLE cadastro_contribuintes (
    doc_corpo VARCHAR(9) NOT NULL,
    doc_filial CHAR(4) NOT NULL DEFAULT '0000',
    doc_digito CHAR(2) NOT NULL,
    tipo_documento ENUM('CPF', 'CNPJ') NOT NULL,

    quantidade_funcionarios INT UNSIGNED NOT NULL DEFAULT 0,
    faturamento_anual DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    data_abertura DATE NOT NULL,

    razao_social_nome VARCHAR(120) NOT NULL,
    nome_fantasia VARCHAR(80) NULL,

    ddd_telefone CHAR(2) NOT NULL,
    numero_telefone VARCHAR(9) NOT NULL,
    email_corporativo VARCHAR(100) NOT NULL,

    cidade_sede VARCHAR(60) NOT NULL,
    estado_uf CHAR(2) NOT NULL,

    PRIMARY KEY (doc_corpo, doc_filial, doc_digito)
);

ALTER TABLE cadastro_contribuintes
MODIFY COLUMN faturamento_anual DECIMAL(15,2) NOT NULL DEFAULT 0.00;

DESCRIBE cadastro_contribuintes;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_incluir(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2),
    IN p_tipo_documento ENUM('CPF', 'CNPJ'),
    IN p_quantidade_funcionarios INT UNSIGNED,
    IN p_faturamento_anual DECIMAL(15,2),
    IN p_data_abertura DATE,
    IN p_razao_social_nome VARCHAR(120),
    IN p_nome_fantasia VARCHAR(80),
    IN p_ddd_telefone CHAR(2),
    IN p_numero_telefone VARCHAR(9),
    IN p_email_corporativo VARCHAR(100),
    IN p_cidade_sede VARCHAR(60),
    IN p_estado_uf CHAR(2)
)
BEGIN
    INSERT INTO cadastro_contribuintes (
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf
    )
    VALUES (
        p_doc_corpo,
        p_doc_filial,
        p_doc_digito,
        p_tipo_documento,
        p_quantidade_funcionarios,
        p_faturamento_anual,
        p_data_abertura,
        p_razao_social_nome,
        p_nome_fantasia,
        p_ddd_telefone,
        p_numero_telefone,
        p_email_corporativo,
        p_cidade_sede,
        p_estado_uf
    );
END$$

DELIMITER ;

CALL sp_contribuinte_incluir(
    '123456789',
    '0000',
    '09',
    'CPF',
    0,
    50000.00,
    '1990-05-15',
    'João da Silva',
    NULL,
    '47',
    '999999999',
    'joao.silva@empresa.com.br',
    'Joinville',
    'SC'
);

SELECT *
FROM cadastro_contribuintes;


DELIMITER $$

CREATE PROCEDURE sp_contribuinte_detalhar(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2)
)
BEGIN
    SELECT
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf
    FROM cadastro_contribuintes
    WHERE doc_corpo = p_doc_corpo
      AND doc_filial = p_doc_filial
      AND doc_digito = p_doc_digito;
END$$

DELIMITER ;


CALL sp_contribuinte_detalhar(
    '123456789',
    '0000',
    '09'
);


DELIMITER $$

CREATE PROCEDURE sp_contribuinte_alterar(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2),
    IN p_tipo_documento ENUM('CPF', 'CNPJ'),
    IN p_quantidade_funcionarios INT UNSIGNED,
    IN p_faturamento_anual DECIMAL(15,2),
    IN p_data_abertura DATE,
    IN p_razao_social_nome VARCHAR(120),
    IN p_nome_fantasia VARCHAR(80),
    IN p_ddd_telefone CHAR(2),
    IN p_numero_telefone VARCHAR(9),
    IN p_email_corporativo VARCHAR(100),
    IN p_cidade_sede VARCHAR(60),
    IN p_estado_uf CHAR(2)
)
BEGIN
    UPDATE cadastro_contribuintes
    SET
        tipo_documento = p_tipo_documento,
        quantidade_funcionarios = p_quantidade_funcionarios,
        faturamento_anual = p_faturamento_anual,
        data_abertura = p_data_abertura,
        razao_social_nome = p_razao_social_nome,
        nome_fantasia = p_nome_fantasia,
        ddd_telefone = p_ddd_telefone,
        numero_telefone = p_numero_telefone,
        email_corporativo = p_email_corporativo,
        cidade_sede = p_cidade_sede,
        estado_uf = p_estado_uf
    WHERE doc_corpo = p_doc_corpo
      AND doc_filial = p_doc_filial
      AND doc_digito = p_doc_digito;
END$$

DELIMITER ;

CALL sp_contribuinte_alterar(
    '123456789',
    '0000',
    '09',
    'CPF',
    0,
    75000.00,
    '1990-05-15',
    'João da Silva',
    NULL,
    '47',
    '988888888',
    'joao.silva.novo@empresa.com.br',
    'Joinville',
    'SC'
);

CALL sp_contribuinte_detalhar(
    '123456789',
    '0000',
    '09'
);


DELIMITER $$

CREATE PROCEDURE sp_contribuinte_pesquisar(
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120),
    IN p_limite INT,
    IN p_offset INT
)
BEGIN
    SELECT
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf
    FROM cadastro_contribuintes
    WHERE
        (
            p_documento IS NULL
            OR p_documento = ''
            OR CONCAT(doc_corpo, doc_filial, doc_digito) LIKE CONCAT('%', p_documento, '%')
        )
        AND
        (
            p_nome IS NULL
            OR p_nome = ''
            OR LOWER(razao_social_nome) LIKE CONCAT('%', LOWER(TRIM(p_nome)), '%')
        )
    ORDER BY
        razao_social_nome ASC,
        doc_corpo ASC,
        doc_filial ASC,
        doc_digito ASC
    LIMIT p_limite OFFSET p_offset;
END$$

DELIMITER ;

CALL sp_contribuinte_pesquisar(
    NULL,
    NULL,
    10,
    0
);

CALL sp_contribuinte_pesquisar(
    NULL,
    'João',
    10,
    0
);

CALL sp_contribuinte_pesquisar(
    NULL,
    'Silva',
    10,
    0
);

CALL sp_contribuinte_pesquisar(
    '123456789',
    NULL,
    10,
    0
);

CALL sp_contribuinte_pesquisar(
    NULL,
    NULL,
    10,
    10
);

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_excluir(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2)
)
BEGIN
    DELETE FROM cadastro_contribuintes
    WHERE doc_corpo = p_doc_corpo
      AND doc_filial = p_doc_filial
      AND doc_digito = p_doc_digito;
END$$

DELIMITER ;

CALL sp_contribuinte_excluir(
    '123456789',
    '0000',
    '09'
);

SELECT
    doc_corpo,
    doc_filial,
    doc_digito,
    tipo_documento,
    quantidade_funcionarios,
    faturamento_anual,
    razao_social_nome,
    nome_fantasia,
    cidade_sede,
    estado_uf,
    email_corporativo
FROM cadastro_contribuintes
WHERE doc_corpo = '12345678'
  AND doc_filial = '0001'
  AND doc_digito = '95';

USE cadastro_contribuintes;

SHOW CREATE TABLE cadastro_contribuintes;

USE cadastro_contribuintes;

SHOW INDEX FROM cadastro_contribuintes;

USE cadastro_contribuintes;

ALTER TABLE cadastro_contribuintes
ADD COLUMN numero_requisicao BIGINT UNSIGNED NOT NULL AUTO_INCREMENT UNIQUE
FIRST;

SELECT
    numero_requisicao,
    tipo_documento,
    doc_corpo,
    doc_filial,
    doc_digito,
    razao_social_nome
FROM cadastro_contribuintes
ORDER BY numero_requisicao;


USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_pesquisar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_pesquisar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120),
    IN p_limite INT,
    IN p_offset INT
)
BEGIN
    SELECT
        numero_requisicao,
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf
    FROM cadastro_contribuintes
    WHERE
        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )
        AND
        (
            p_documento IS NULL
            OR p_documento = ''
            OR (
                CHAR_LENGTH(p_documento) = 11
                AND tipo_documento = 'CPF'
                AND CONCAT(doc_corpo, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )
            OR (
                CHAR_LENGTH(p_documento) = 14
                AND tipo_documento = 'CNPJ'
                AND CONCAT(doc_corpo, doc_filial, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )
        )
        AND
        (
            p_nome IS NULL
            OR p_nome = ''
            OR LOWER(razao_social_nome)
                LIKE CONCAT('%', LOWER(TRIM(p_nome)), '%')
        )
    ORDER BY
        razao_social_nome ASC,
        numero_requisicao ASC
    LIMIT p_limite OFFSET p_offset;
END$$

DELIMITER ;

USE cadastro_contribuintes;


DROP PROCEDURE IF EXISTS sp_contribuinte_detalhar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_detalhar(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2)
)
BEGIN
    SELECT
        numero_requisicao,
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf
    FROM cadastro_contribuintes
    WHERE doc_corpo = p_doc_corpo
      AND doc_filial = p_doc_filial
      AND doc_digito = p_doc_digito;
END$$

DELIMITER ;

USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_pesquisar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_pesquisar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120),
    IN p_ordem VARCHAR(20),
    IN p_direcao VARCHAR(4),
    IN p_limite INT,
    IN p_offset INT
)
BEGIN

    -- Define uma ordenação segura caso os parâmetros
    -- sejam nulos ou inválidos.
    IF p_ordem IS NULL
       OR p_ordem NOT IN ('REQUISICAO', 'NOME') THEN

        SET p_ordem = 'REQUISICAO';

    END IF;

    IF p_direcao IS NULL
       OR p_direcao NOT IN ('ASC', 'DESC') THEN

        SET p_direcao = 'ASC';

    END IF;


    SELECT
        numero_requisicao,
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf

    FROM cadastro_contribuintes

    WHERE

        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )

        AND

        (
            p_documento IS NULL
            OR p_documento = ''

            OR (
                CHAR_LENGTH(p_documento) = 11
                AND tipo_documento = 'CPF'
                AND CONCAT(doc_corpo, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )

            OR (
                CHAR_LENGTH(p_documento) = 14
                AND tipo_documento = 'CNPJ'
                AND CONCAT(doc_corpo, doc_filial, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )
        )

        AND

        (
            p_nome IS NULL
            OR p_nome = ''
            OR LOWER(razao_social_nome)
                LIKE CONCAT('%', LOWER(TRIM(p_nome)), '%')
        )

    ORDER BY

        -- Requisição crescente
        CASE
            WHEN p_ordem = 'REQUISICAO'
                 AND p_direcao = 'ASC'
            THEN numero_requisicao
        END ASC,

        -- Requisição decrescente
        CASE
            WHEN p_ordem = 'REQUISICAO'
                 AND p_direcao = 'DESC'
            THEN numero_requisicao
        END DESC,

        -- Nome crescente
        CASE
            WHEN p_ordem = 'NOME'
                 AND p_direcao = 'ASC'
            THEN razao_social_nome
        END ASC,

        -- Nome decrescente
        CASE
            WHEN p_ordem = 'NOME'
                 AND p_direcao = 'DESC'
            THEN razao_social_nome
        END DESC,

        -- Critério de desempate.
        -- Garante uma ordem estável quando dois nomes forem iguais.
        numero_requisicao ASC

    LIMIT p_limite OFFSET p_offset;

END$$

DELIMITER ;

USE cadastro_contribuintes;

CALL sp_contribuinte_pesquisar(
    NULL,
    NULL,
    NULL,
    'REQUISICAO',
    'ASC',
    10,
    0
);

CALL sp_contribuinte_pesquisar(
    NULL,
    NULL,
    NULL,
    'REQUISICAO',
    'DESC',
    10,
    0
);

CALL sp_contribuinte_pesquisar(
    NULL,
    NULL,
    NULL,
    'NOME',
    'ASC',
    10,
    0
);

CALL sp_contribuinte_pesquisar(
    NULL,
    NULL,
    NULL,
    'NOME',
    'DESC',
    10,
    0
);


USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_contar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_contar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120)
)
BEGIN

    SELECT COUNT(*) AS total
    FROM cadastro_contribuintes
    WHERE
        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )
        AND
        (
            p_documento IS NULL
            OR p_documento = ''
            OR (
                CHAR_LENGTH(p_documento) = 11
                AND tipo_documento = 'CPF'
                AND CONCAT(doc_corpo, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )
            OR (
                CHAR_LENGTH(p_documento) = 14
                AND tipo_documento = 'CNPJ'
                AND CONCAT(doc_corpo, doc_filial, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )
        )
        AND
        (
            p_nome IS NULL
            OR p_nome = ''
            OR LOWER(razao_social_nome)
                LIKE CONCAT('%', LOWER(TRIM(p_nome)), '%')
        );

END$$

DELIMITER ;

SELECT *
FROM cadastro_contribuintes
WHERE doc_corpo = '12345678'
  AND doc_filial = '0001'
  AND doc_digito = '90';
  
  SHOW PROCEDURE STATUS
WHERE Db = 'cadastro_contribuintes';

SHOW CREATE PROCEDURE sp_contribuinte_excluir;

CALL sp_contribuinte_excluir(
    '12345678',
    '0001',
    '90'
);

SHOW PROCEDURE STATUS
WHERE Db = 'cadastro_contribuintes';

DROP PROCEDURE IF EXISTS cadastro_contribuintes.sp_contribuinte_pesquisar;

DELIMITER $$

CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_contribuinte_pesquisar`(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120),
    IN p_ordem VARCHAR(20),
    IN p_direcao VARCHAR(4),
    IN p_limite INT,
    IN p_offset INT
)
BEGIN

    -- Define uma ordenação segura caso os parâmetros
    -- sejam nulos ou inválidos.
    IF p_ordem IS NULL
       OR p_ordem NOT IN ('REQUISICAO', 'NOME') THEN

        SET p_ordem = 'REQUISICAO';

    END IF;

    IF p_direcao IS NULL
       OR p_direcao NOT IN ('ASC', 'DESC') THEN

        SET p_direcao = 'ASC';

    END IF;


    SELECT
        numero_requisicao,
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf

    FROM cadastro_contribuintes

    WHERE

        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )

        AND

        (
            p_documento IS NULL
            OR p_documento = ''

            OR CONCAT(
                doc_corpo,
                doc_filial,
                doc_digito
            ) LIKE CONCAT('%', p_documento, '%')
        )

        AND

        (
            p_nome IS NULL
            OR p_nome = ''
            OR LOWER(razao_social_nome)
                LIKE CONCAT('%', LOWER(TRIM(p_nome)), '%')
        )

    ORDER BY

        -- Requisição crescente
        CASE
            WHEN p_ordem = 'REQUISICAO'
                 AND p_direcao = 'ASC'
            THEN numero_requisicao
        END ASC,

        -- Requisição decrescente
        CASE
            WHEN p_ordem = 'REQUISICAO'
                 AND p_direcao = 'DESC'
            THEN numero_requisicao
        END DESC,

        -- Nome crescente
        CASE
            WHEN p_ordem = 'NOME'
                 AND p_direcao = 'ASC'
            THEN razao_social_nome
        END ASC,

        -- Nome decrescente
        CASE
            WHEN p_ordem = 'NOME'
                 AND p_direcao = 'DESC'
            THEN razao_social_nome
        END DESC,

        -- Critério de desempate pelo documento.
        -- Mantém a paginação estável quando
        -- dois ou mais contribuintes possuem
        -- o mesmo Nome/Razão Social.
        CONCAT(
            doc_corpo,
            doc_filial,
            doc_digito
        ) ASC

    LIMIT p_limite OFFSET p_offset;

END$$

DELIMITER ;


SELECT
    numero_requisicao,
    tipo_documento,
    doc_corpo,
    doc_filial,
    doc_digito,
    CONCAT(
        doc_corpo,
        doc_filial,
        doc_digito
    ) AS documento_montado
FROM cadastro_contribuintes
WHERE tipo_documento = 'CPF'
LIMIT 10;
USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_pesquisar;
DROP PROCEDURE IF EXISTS sp_contribuinte_contar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_pesquisar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120),
    IN p_ordem VARCHAR(20),
    IN p_direcao VARCHAR(4),
    IN p_limite INT,
    IN p_offset INT
)
BEGIN

    /*
     * =========================================================
     * VALIDAÇÃO DOS PARÂMETROS DE ORDENAÇÃO
     * =========================================================
     *
     * A Requisição continua disponível como funcionalidade
     * adicional.
     *
     * A ordenação por Nome utiliza Documento como critério
     * de desempate estável.
     */

    IF p_ordem IS NULL
       OR p_ordem NOT IN ('REQUISICAO', 'NOME') THEN

        SET p_ordem = 'REQUISICAO';

    END IF;

    IF p_direcao IS NULL
       OR p_direcao NOT IN ('ASC', 'DESC') THEN

        SET p_direcao = 'ASC';

    END IF;


    /*
     * =========================================================
     * CONSULTA
     * =========================================================
     */

    SELECT
        numero_requisicao,
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf

    FROM cadastro_contribuintes

    WHERE

        /*
         * FILTRO POR REQUISIÇÃO
         *
         * Continua existindo como funcionalidade adicional.
         */
        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )

        AND

        /*
         * FILTRO POR DOCUMENTO
         *
         * CPF:
         *     doc_corpo + doc_digito
         *
         * CNPJ:
         *     doc_corpo + doc_filial + doc_digito
         *
         * Assim o CPF não recebe os quatro zeros de doc_filial.
         */
        (
            p_documento IS NULL
            OR p_documento = ''

            OR (
                tipo_documento = 'CPF'
                AND CONCAT(
                    doc_corpo,
                    doc_digito
                ) LIKE CONCAT('%', p_documento, '%')
            )

            OR (
                tipo_documento = 'CNPJ'
                AND CONCAT(
                    doc_corpo,
                    doc_filial,
                    doc_digito
                ) LIKE CONCAT('%', p_documento, '%')
            )
        )

        AND

        /*
         * FILTRO POR NOME / RAZÃO SOCIAL
         *
         * A collation utf8mb4_0900_ai_ci da tabela já fornece
         * comportamento case-insensitive.
         *
         * TRIM remove espaços excedentes das extremidades.
         */
        (
            p_nome IS NULL
            OR p_nome = ''
            OR razao_social_nome LIKE CONCAT(
                '%',
                TRIM(p_nome),
                '%'
            )
        )


    /*
     * =========================================================
     * ORDENAÇÃO
     * =========================================================
     */

    ORDER BY

        /*
         * REQUISIÇÃO ASC
         */
        CASE
            WHEN p_ordem = 'REQUISICAO'
                 AND p_direcao = 'ASC'
            THEN numero_requisicao
        END ASC,

        /*
         * REQUISIÇÃO DESC
         */
        CASE
            WHEN p_ordem = 'REQUISICAO'
                 AND p_direcao = 'DESC'
            THEN numero_requisicao
        END DESC,

        /*
         * NOME ASC
         */
        CASE
            WHEN p_ordem = 'NOME'
                 AND p_direcao = 'ASC'
            THEN razao_social_nome
        END ASC,

        /*
         * NOME DESC
         */
        CASE
            WHEN p_ordem = 'NOME'
                 AND p_direcao = 'DESC'
            THEN razao_social_nome
        END DESC,

        /*
         * =====================================================
         * DESEMPATE ESTÁVEL POR DOCUMENTO
         * =====================================================
         *
         * CPF:
         *     doc_corpo + doc_digito
         *
         * CNPJ:
         *     doc_corpo + doc_filial + doc_digito
         */
        CASE
            WHEN tipo_documento = 'CPF'
            THEN CONCAT(
                doc_corpo,
                doc_digito
            )

            WHEN tipo_documento = 'CNPJ'
            THEN CONCAT(
                doc_corpo,
                doc_filial,
                doc_digito
            )
        END ASC

    LIMIT p_limite
    OFFSET p_offset;

END$$

DELIMITER ;

CALL sp_contribuinte_pesquisar(
    NULL,
    NULL,
    NULL,
    'NOME',
    'ASC',
    10,
    0
);

CALL sp_contribuinte_contar(
    NULL,
    NULL,
    NULL
);

USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_contar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_contar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120)
)
BEGIN

    SELECT
        COUNT(*) AS total

    FROM cadastro_contribuintes

    WHERE

        /*
         * FILTRO POR REQUISIÇÃO
         */
        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )

        AND

        /*
         * FILTRO POR DOCUMENTO
         *
         * CPF:
         *     doc_corpo + doc_digito
         *
         * CNPJ:
         *     doc_corpo + doc_filial + doc_digito
         *
         * Isso evita que o CPF receba os quatro zeros
         * existentes em doc_filial.
         */
        (
            p_documento IS NULL
            OR p_documento = ''

            OR (
                tipo_documento = 'CPF'
                AND CONCAT(
                    doc_corpo,
                    doc_digito
                ) LIKE CONCAT('%', p_documento, '%')
            )

            OR (
                tipo_documento = 'CNPJ'
                AND CONCAT(
                    doc_corpo,
                    doc_filial,
                    doc_digito
                ) LIKE CONCAT('%', p_documento, '%')
            )
        )

        AND

        /*
         * FILTRO POR NOME / RAZÃO SOCIAL
         *
         * A comparação respeita a collation do banco.
         */
        (
            p_nome IS NULL
            OR p_nome = ''
            OR razao_social_nome LIKE CONCAT(
                '%',
                TRIM(p_nome),
                '%'
            )
        );

END$$

DELIMITER ;

CALL sp_contribuinte_contar(
    NULL,
    NULL,
    NULL
);

CALL sp_contribuinte_pesquisar(
    NULL,
    '00977866501',
    NULL,
    'NOME',
    'ASC',
    10,
    0
);

CALL sp_contribuinte_pesquisar(
    NULL,
    '009778',
    NULL,
    'NOME',
    'ASC',
    10,
    0
);
CALL sp_contribuinte_contar(NULL, NULL, NULL);
CALL sp_contribuinte_contar(NULL, '00977866501', NULL);
CALL sp_contribuinte_contar(NULL, '009778665', NULL);

USE cadastro_contribuintes;

SELECT
    numero_requisicao,
    tipo_documento,
    doc_corpo,
    doc_filial,
    doc_digito,
    razao_social_nome,
    cidade_sede,
    estado_uf
FROM cadastro_contribuintes
WHERE numero_requisicao = 1;

USE cadastro_contribuintes;

SELECT *
FROM cadastro_contribuintes
WHERE numero_requisicao = 9;

SELECT COUNT(*) AS total
FROM cadastro_contribuintes;

SELECT
    numero_requisicao,
    tipo_documento,
    doc_corpo,
    doc_filial,
    doc_digito,
    razao_social_nome
FROM cadastro_contribuintes
ORDER BY numero_requisicao;

SELECT
    numero_requisicao,
    doc_corpo,
    doc_filial,
    doc_digito,
    tipo_documento,
    razao_social_nome
FROM cadastro_contribuintes
WHERE numero_requisicao = 18;

UPDATE cadastro_contribuintes
SET doc_filial = '0000'
WHERE numero_requisicao = 18;

USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_incluir;
DROP PROCEDURE IF EXISTS sp_contribuinte_detalhar;
DROP PROCEDURE IF EXISTS sp_contribuinte_alterar;
DROP PROCEDURE IF EXISTS sp_contribuinte_pesquisar;
DROP PROCEDURE IF EXISTS sp_contribuinte_contar;
DROP PROCEDURE IF EXISTS sp_contribuinte_excluir;

SHOW CREATE PROCEDURE sp_contribuinte_incluir;

DROP PROCEDURE IF EXISTS sp_contribuinte_incluir;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_incluir(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2),
    IN p_tipo_documento ENUM('CPF', 'CNPJ'),
    IN p_quantidade_funcionarios INT UNSIGNED,
    IN p_faturamento_anual DECIMAL(15,2),
    IN p_data_abertura DATE,
    IN p_razao_social_nome VARCHAR(120),
    IN p_nome_fantasia VARCHAR(80),
    IN p_ddd_telefone CHAR(2),
    IN p_numero_telefone VARCHAR(9),
    IN p_email_corporativo VARCHAR(100),
    IN p_cidade_sede VARCHAR(60),
    IN p_estado_uf CHAR(2)
)
BEGIN

    SET p_doc_corpo = TRIM(p_doc_corpo);
    SET p_doc_filial = TRIM(p_doc_filial);
    SET p_doc_digito = TRIM(p_doc_digito);
    SET p_tipo_documento = UPPER(TRIM(p_tipo_documento));
    SET p_razao_social_nome = TRIM(p_razao_social_nome);
    SET p_nome_fantasia = NULLIF(TRIM(p_nome_fantasia), '');
    SET p_ddd_telefone = TRIM(p_ddd_telefone);
    SET p_numero_telefone = TRIM(p_numero_telefone);
    SET p_email_corporativo = LOWER(TRIM(p_email_corporativo));
    SET p_cidade_sede = TRIM(p_cidade_sede);
    SET p_estado_uf = UPPER(TRIM(p_estado_uf));


    IF p_tipo_documento IS NULL
       OR p_tipo_documento NOT IN ('CPF', 'CNPJ') THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Tipo de documento está em formato inválido.';

    END IF;


    IF p_tipo_documento = 'CPF' THEN

        IF p_doc_corpo IS NULL
           OR p_doc_corpo NOT REGEXP '^[0-9]{9}$'
           OR p_doc_filial <> '0000'
           OR p_doc_digito IS NULL
           OR p_doc_digito NOT REGEXP '^[0-9]{2}$' THEN

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT =
                    'O campo Documento está em formato inválido.';

        END IF;

        SET p_nome_fantasia = NULL;
        SET p_quantidade_funcionarios = 0;

    ELSE

        IF p_doc_corpo IS NULL
           OR p_doc_corpo NOT REGEXP '^[0-9]{8}$'
           OR p_doc_filial IS NULL
           OR p_doc_filial NOT REGEXP '^[0-9]{4}$'
           OR p_doc_digito IS NULL
           OR p_doc_digito NOT REGEXP '^[0-9]{2}$' THEN

            SIGNAL SQLSTATE '45000'
                SET MESSAGE_TEXT =
                    'O campo Documento está em formato inválido.';

        END IF;

    END IF;


    IF p_razao_social_nome IS NULL
       OR p_razao_social_nome = ''
       OR CHAR_LENGTH(p_razao_social_nome) < 3
       OR CHAR_LENGTH(p_razao_social_nome) > 120 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Nome/Razão social está em formato inválido.';

    END IF;


    IF p_tipo_documento = 'CNPJ'
       AND p_nome_fantasia IS NOT NULL
       AND CHAR_LENGTH(p_nome_fantasia) > 80 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Nome fantasia está em formato inválido.';

    END IF;


    IF p_faturamento_anual IS NULL
       OR p_faturamento_anual < 0
       OR p_faturamento_anual > 9999999999999.99 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Faturamento anual está em formato inválido.';

    END IF;


    IF p_data_abertura IS NULL THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Informe o campo Data de abertura.';

    END IF;


    IF p_data_abertura > CURRENT_DATE() THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Data de abertura está em formato inválido.';

    END IF;


    IF p_ddd_telefone IS NULL
       OR p_ddd_telefone NOT REGEXP '^[0-9]{2}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo DDD está em formato inválido.';

    END IF;


    IF p_ddd_telefone NOT IN (
        '11','12','13','14','15','16','17','18','19',
        '21','22','24','27','28',
        '31','32','33','34','35','37','38',
        '41','42','43','44','45','46','47','48','49',
        '51','53','54','55',
        '61','62','63','64','65','66','67','68','69',
        '71','73','74','75','77','79',
        '81','82','83','84','85','86','87','88','89',
        '91','92','93','94','95','96','97','98','99'
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo DDD está em formato inválido.';

    END IF;


    IF p_numero_telefone IS NULL
       OR p_numero_telefone NOT REGEXP '^[0-9]{8,9}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Telefone está em formato inválido.';

    END IF;


    IF CHAR_LENGTH(p_numero_telefone) = 9
       AND LEFT(p_numero_telefone, 1) <> '9' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Telefone está em formato inválido.';

    END IF;


    IF p_email_corporativo IS NULL
       OR p_email_corporativo = ''
       OR CHAR_LENGTH(p_email_corporativo) > 100
       OR p_email_corporativo NOT REGEXP
          '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo E-mail corporativo está em formato inválido.';

    END IF;


    IF p_cidade_sede IS NULL
       OR p_cidade_sede = ''
       OR CHAR_LENGTH(p_cidade_sede) > 60
       OR p_cidade_sede REGEXP '[0-9]' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Cidade está em formato inválido.';

    END IF;


    IF p_estado_uf NOT IN (
        'AC','AL','AP','AM','BA','CE','DF','ES','GO',
        'MA','MT','MS','MG','PA','PB','PR','PE','PI',
        'RJ','RN','RS','RO','RR','SC','SE','SP','TO'
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo UF está em formato inválido.';

    END IF;


    IF EXISTS (
        SELECT 1
        FROM cadastro_contribuintes
        WHERE doc_corpo = p_doc_corpo
          AND doc_filial = p_doc_filial
          AND doc_digito = p_doc_digito
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Já existe um contribuinte cadastrado com este documento.';

    END IF;


    INSERT INTO cadastro_contribuintes (
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf
    )
    VALUES (
        p_doc_corpo,
        p_doc_filial,
        p_doc_digito,
        p_tipo_documento,
        p_quantidade_funcionarios,
        p_faturamento_anual,
        p_data_abertura,
        p_razao_social_nome,
        p_nome_fantasia,
        p_ddd_telefone,
        p_numero_telefone,
        p_email_corporativo,
        p_cidade_sede,
        p_estado_uf
    );

END$$

DELIMITER ;

USE cadastro_contribuintes;

SHOW CREATE PROCEDURE sp_contribuinte_incluir;

USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_detalhar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_detalhar(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2)
)
BEGIN

    SELECT
        numero_requisicao,
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf
    FROM cadastro_contribuintes
    WHERE doc_corpo = TRIM(p_doc_corpo)
      AND doc_filial = TRIM(p_doc_filial)
      AND doc_digito = TRIM(p_doc_digito);

END$$

DELIMITER ;

SHOW CREATE PROCEDURE sp_contribuinte_detalhar;

USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_alterar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_alterar(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2),
    IN p_tipo_documento ENUM('CPF', 'CNPJ'),
    IN p_quantidade_funcionarios INT UNSIGNED,
    IN p_faturamento_anual DECIMAL(15,2),
    IN p_data_abertura DATE,
    IN p_razao_social_nome VARCHAR(120),
    IN p_nome_fantasia VARCHAR(80),
    IN p_ddd_telefone CHAR(2),
    IN p_numero_telefone VARCHAR(9),
    IN p_email_corporativo VARCHAR(100),
    IN p_cidade_sede VARCHAR(60),
    IN p_estado_uf CHAR(2)
)
BEGIN

    SET p_doc_corpo = TRIM(p_doc_corpo);
    SET p_doc_filial = TRIM(p_doc_filial);
    SET p_doc_digito = TRIM(p_doc_digito);
    SET p_razao_social_nome = TRIM(p_razao_social_nome);
    SET p_nome_fantasia = NULLIF(TRIM(p_nome_fantasia), '');
    SET p_ddd_telefone = TRIM(p_ddd_telefone);
    SET p_numero_telefone = TRIM(p_numero_telefone);
    SET p_email_corporativo = LOWER(TRIM(p_email_corporativo));
    SET p_cidade_sede = TRIM(p_cidade_sede);
    SET p_estado_uf = UPPER(TRIM(p_estado_uf));

    IF NOT EXISTS (
        SELECT 1
        FROM cadastro_contribuintes
        WHERE doc_corpo = p_doc_corpo
          AND doc_filial = p_doc_filial
          AND doc_digito = p_doc_digito
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O contribuinte não foi localizado. Atualize a listagem e tente novamente.';

    END IF;

    IF p_tipo_documento = 'CPF' THEN

        SET p_doc_filial = '0000';
        SET p_quantidade_funcionarios = 0;
        SET p_nome_fantasia = NULL;

    END IF;

    IF p_razao_social_nome IS NULL
       OR p_razao_social_nome = ''
       OR CHAR_LENGTH(p_razao_social_nome) < 3
       OR CHAR_LENGTH(p_razao_social_nome) > 120 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Nome/Razão social está em formato inválido.';

    END IF;

    IF p_tipo_documento = 'CNPJ'
       AND p_nome_fantasia IS NOT NULL
       AND CHAR_LENGTH(p_nome_fantasia) > 80 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Nome fantasia está em formato inválido.';

    END IF;

    IF p_faturamento_anual IS NULL
       OR p_faturamento_anual < 0
       OR p_faturamento_anual > 9999999999999.99 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Faturamento anual está em formato inválido.';

    END IF;

    IF p_data_abertura IS NULL THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Informe o campo Data de abertura.';

    END IF;

    IF p_data_abertura > CURRENT_DATE() THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Data de abertura está em formato inválido.';

    END IF;

    IF p_ddd_telefone IS NULL
       OR p_ddd_telefone NOT REGEXP '^[0-9]{2}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo DDD está em formato inválido.';

    END IF;

    IF p_ddd_telefone NOT IN (
        '11','12','13','14','15','16','17','18','19',
        '21','22','24','27','28',
        '31','32','33','34','35','37','38',
        '41','42','43','44','45','46','47','48','49',
        '51','53','54','55',
        '61','62','63','64','65','66','67','68','69',
        '71','73','74','75','77','79',
        '81','82','83','84','85','86','87','88','89',
        '91','92','93','94','95','96','97','98','99'
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo DDD está em formato inválido.';

    END IF;

    IF p_numero_telefone IS NULL
       OR p_numero_telefone NOT REGEXP '^[0-9]{8,9}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Telefone está em formato inválido.';

    END IF;

    IF CHAR_LENGTH(p_numero_telefone) = 9
       AND LEFT(p_numero_telefone, 1) <> '9' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Telefone está em formato inválido.';

    END IF;

    IF p_email_corporativo IS NULL
       OR p_email_corporativo = ''
       OR CHAR_LENGTH(p_email_corporativo) > 100
       OR p_email_corporativo NOT REGEXP
          '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo E-mail corporativo está em formato inválido.';

    END IF;

    IF p_cidade_sede IS NULL
       OR p_cidade_sede = ''
       OR CHAR_LENGTH(p_cidade_sede) > 60
       OR p_cidade_sede REGEXP '[0-9]' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo Cidade está em formato inválido.';

    END IF;

    IF p_estado_uf NOT IN (
        'AC','AL','AP','AM','BA','CE','DF','ES','GO',
        'MA','MT','MS','MG','PA','PB','PR','PE','PI',
        'RJ','RN','RS','RO','RR','SC','SE','SP','TO'
    ) THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O campo UF está em formato inválido.';

    END IF;

    UPDATE cadastro_contribuintes
       SET tipo_documento = p_tipo_documento,
           quantidade_funcionarios = p_quantidade_funcionarios,
           faturamento_anual = p_faturamento_anual,
           data_abertura = p_data_abertura,
           razao_social_nome = p_razao_social_nome,
           nome_fantasia = p_nome_fantasia,
           ddd_telefone = p_ddd_telefone,
           numero_telefone = p_numero_telefone,
           email_corporativo = p_email_corporativo,
           cidade_sede = p_cidade_sede,
           estado_uf = p_estado_uf
     WHERE doc_corpo = p_doc_corpo
       AND doc_filial = p_doc_filial
       AND doc_digito = p_doc_digito;

END$$

DELIMITER ;

USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_pesquisar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_pesquisar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120),
    IN p_ordem VARCHAR(20),
    IN p_direcao VARCHAR(4),
    IN p_limite INT,
    IN p_offset INT
)
BEGIN

    SET p_documento = NULLIF(TRIM(p_documento), '');
    SET p_nome = NULLIF(TRIM(p_nome), '');

    IF p_ordem IS NULL
       OR p_ordem NOT IN ('REQUISICAO', 'NOME', 'DOCUMENTO') THEN

        SET p_ordem = 'REQUISICAO';

    END IF;

    IF p_direcao IS NULL
       OR p_direcao NOT IN ('ASC', 'DESC') THEN

        SET p_direcao = 'ASC';

    END IF;

    IF p_limite IS NULL
       OR p_limite < 1
       OR p_limite > 10 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Limite de registros por página inválido.';

    END IF;

    IF p_offset IS NULL
       OR p_offset < 0 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Offset de paginação inválido.';

    END IF;

    SELECT
        numero_requisicao,
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf

    FROM cadastro_contribuintes

    WHERE
        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )

        AND

        (
            p_documento IS NULL

            OR

            (
                tipo_documento = 'CPF'
                AND CONCAT(doc_corpo, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )

            OR

            (
                tipo_documento = 'CNPJ'
                AND CONCAT(doc_corpo, doc_filial, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )
        )

        AND

        (
            p_nome IS NULL
            OR razao_social_nome LIKE CONCAT('%', p_nome, '%')
        )

    ORDER BY

        CASE
            WHEN p_ordem = 'REQUISICAO'
             AND p_direcao = 'ASC'
            THEN numero_requisicao
        END ASC,

        CASE
            WHEN p_ordem = 'REQUISICAO'
             AND p_direcao = 'DESC'
            THEN numero_requisicao
        END DESC,

        CASE
            WHEN p_ordem = 'NOME'
             AND p_direcao = 'ASC'
            THEN razao_social_nome
        END ASC,

        CASE
            WHEN p_ordem = 'NOME'
             AND p_direcao = 'DESC'
            THEN razao_social_nome
        END DESC,

        CASE
            WHEN p_ordem = 'DOCUMENTO'
             AND p_direcao = 'ASC'
            THEN
                CASE
                    WHEN tipo_documento = 'CPF'
                    THEN CONCAT(doc_corpo, doc_digito)

                    WHEN tipo_documento = 'CNPJ'
                    THEN CONCAT(doc_corpo, doc_filial, doc_digito)
                END
        END ASC,

        CASE
            WHEN p_ordem = 'DOCUMENTO'
             AND p_direcao = 'DESC'
            THEN
                CASE
                    WHEN tipo_documento = 'CPF'
                    THEN CONCAT(doc_corpo, doc_digito)

                    WHEN tipo_documento = 'CNPJ'
                    THEN CONCAT(doc_corpo, doc_filial, doc_digito)
                END
        END DESC,

        /*
         * Desempate estável pelo documento.
         * CPF = 9 + 2
         * CNPJ = 8 + 4 + 2
         */
        CASE
            WHEN tipo_documento = 'CPF'
            THEN CONCAT(doc_corpo, doc_digito)

            WHEN tipo_documento = 'CNPJ'
            THEN CONCAT(doc_corpo, doc_filial, doc_digito)
        END ASC,

        /*
         * Último desempate pela requisição.
         */
        numero_requisicao ASC

    LIMIT p_limite
    OFFSET p_offset;

END$$

DELIMITER ;

USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_contar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_contar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120)
)
BEGIN

    SET p_documento = NULLIF(TRIM(p_documento), '');
    SET p_nome = NULLIF(TRIM(p_nome), '');

    SELECT
        COUNT(*) AS total

    FROM cadastro_contribuintes

    WHERE
        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )

        AND

        (
            p_documento IS NULL

            OR

            (
                tipo_documento = 'CPF'
                AND CONCAT(doc_corpo, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )

            OR

            (
                tipo_documento = 'CNPJ'
                AND CONCAT(doc_corpo, doc_filial, doc_digito)
                    LIKE CONCAT('%', p_documento, '%')
            )
        )

        AND

        (
            p_nome IS NULL
            OR razao_social_nome LIKE CONCAT('%', p_nome, '%')
        );

END$$

DELIMITER ;
SHOW CREATE PROCEDURE sp_contribuinte_contar;

USE cadastro_contribuintes;

DROP PROCEDURE IF EXISTS sp_contribuinte_excluir;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_excluir(
    IN p_doc_corpo VARCHAR(9),
    IN p_doc_filial CHAR(4),
    IN p_doc_digito CHAR(2)
)
BEGIN

    SET p_doc_corpo = TRIM(p_doc_corpo);
    SET p_doc_filial = TRIM(p_doc_filial);
    SET p_doc_digito = TRIM(p_doc_digito);

    IF p_doc_corpo IS NULL
       OR p_doc_corpo = ''
       OR p_doc_corpo NOT REGEXP '^[0-9]{8,9}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O contribuinte não foi localizado. Atualize a listagem e tente novamente.';

    END IF;

    IF p_doc_filial IS NULL
       OR p_doc_filial NOT REGEXP '^[0-9]{4}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O contribuinte não foi localizado. Atualize a listagem e tente novamente.';

    END IF;

    IF p_doc_digito IS NULL
       OR p_doc_digito NOT REGEXP '^[0-9]{2}$' THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O contribuinte não foi localizado. Atualize a listagem e tente novamente.';

    END IF;

    DELETE FROM cadastro_contribuintes
    WHERE doc_corpo = p_doc_corpo
      AND doc_filial = p_doc_filial
      AND doc_digito = p_doc_digito;

    IF ROW_COUNT() = 0 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'O contribuinte não foi localizado. Atualize a listagem e tente novamente.';

    END IF;

END$$

DELIMITER ;
SHOW CREATE PROCEDURE sp_contribuinte_excluir;