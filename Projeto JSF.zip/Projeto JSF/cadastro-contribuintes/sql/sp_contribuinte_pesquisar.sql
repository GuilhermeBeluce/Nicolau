DROP PROCEDURE IF EXISTS sp_contribuinte_pesquisar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_pesquisar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120),
    IN p_ordem VARCHAR(20),
    IN p_direcao VARCHAR(4),
    IN p_limite INT,
    IN p_offset INT
)
BEGIN

    /*
     * =========================================================
     * VALIDAÇÃO DOS PARÂMETROS
     * =========================================================
     */

    IF p_ordem IS NULL
       OR p_ordem NOT IN ('REQUISICAO', 'NOME', 'DOCUMENTO') THEN

        SET p_ordem = 'REQUISICAO';

    END IF;

    IF p_direcao IS NULL
       OR p_direcao NOT IN ('ASC', 'DESC') THEN

        SET p_direcao = 'ASC';

    END IF;

    IF p_limite IS NULL
       OR p_limite < 1
       OR p_limite > 10 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Limite de registros por página inválido.';

    END IF;

    IF p_offset IS NULL
       OR p_offset < 0 THEN

        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT =
                'Offset de paginação inválido.';

    END IF;


    /*
     * =========================================================
     * CONSULTA
     * =========================================================
     */

    SELECT
        numero_requisicao,
        doc_corpo,
        doc_filial,
        doc_digito,
        tipo_documento,
        quantidade_funcionarios,
        faturamento_anual,
        data_abertura,
        razao_social_nome,
        nome_fantasia,
        ddd_telefone,
        numero_telefone,
        email_corporativo,
        cidade_sede,
        estado_uf

    FROM cadastro_contribuintes

    WHERE

        /*
         * -----------------------------------------------------
         * FILTRO POR REQUISIÇÃO
         * -----------------------------------------------------
         */

        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )

        AND

        /*
         * -----------------------------------------------------
         * FILTRO POR DOCUMENTO
         * -----------------------------------------------------
         *
         * CPF:
         *   doc_corpo + doc_digito
         *
         * CNPJ:
         *   doc_corpo + doc_filial + doc_digito
         *
         * A comparação é parcial.
         */

        (
            p_documento IS NULL
            OR p_documento = ''

            OR
            (
                tipo_documento = 'CPF'
                AND CONCAT(
                    doc_corpo,
                    doc_digito
                ) LIKE CONCAT('%', p_documento, '%')
            )

            OR
            (
                tipo_documento = 'CNPJ'
                AND CONCAT(
                    doc_corpo,
                    doc_filial,
                    doc_digito
                ) LIKE CONCAT('%', p_documento, '%')
            )
        )

        AND

        /*
         * -----------------------------------------------------
         * FILTRO POR NOME / RAZÃO SOCIAL
         * -----------------------------------------------------
         *
         * A comparação respeita a collation
         * utf8mb4_0900_ai_ci.
         */

        (
            p_nome IS NULL
            OR p_nome = ''

            OR razao_social_nome LIKE CONCAT(
                '%',
                TRIM(p_nome),
                '%'
            )
        )


    /*
     * =========================================================
     * ORDENAÇÃO
     * =========================================================
     */

    ORDER BY

        /*
         * -----------------------------------------------------
         * REQUISIÇÃO ASC
         * -----------------------------------------------------
         */

        CASE
            WHEN p_ordem = 'REQUISICAO'
                 AND p_direcao = 'ASC'
            THEN numero_requisicao
        END ASC,


        /*
         * -----------------------------------------------------
         * REQUISIÇÃO DESC
         * -----------------------------------------------------
         */

        CASE
            WHEN p_ordem = 'REQUISICAO'
                 AND p_direcao = 'DESC'
            THEN numero_requisicao
        END DESC,


        /*
         * -----------------------------------------------------
         * NOME ASC
         * -----------------------------------------------------
         */

        CASE
            WHEN p_ordem = 'NOME'
                 AND p_direcao = 'ASC'
            THEN razao_social_nome
        END ASC,


        /*
         * -----------------------------------------------------
         * NOME DESC
         * -----------------------------------------------------
         */

        CASE
            WHEN p_ordem = 'NOME'
                 AND p_direcao = 'DESC'
            THEN razao_social_nome
        END DESC,


        /*
         * -----------------------------------------------------
         * DOCUMENTO ASC
         * -----------------------------------------------------
         */

        CASE
            WHEN p_ordem = 'DOCUMENTO'
                 AND p_direcao = 'ASC'
            THEN
                CASE
                    WHEN tipo_documento = 'CPF'
                    THEN CONCAT(
                        doc_corpo,
                        doc_digito
                    )

                    WHEN tipo_documento = 'CNPJ'
                    THEN CONCAT(
                        doc_corpo,
                        doc_filial,
                        doc_digito
                    )
                END
        END ASC,


        /*
         * -----------------------------------------------------
         * DOCUMENTO DESC
         * -----------------------------------------------------
         */

        CASE
            WHEN p_ordem = 'DOCUMENTO'
                 AND p_direcao = 'DESC'
            THEN
                CASE
                    WHEN tipo_documento = 'CPF'
                    THEN CONCAT(
                        doc_corpo,
                        doc_digito
                    )

                    WHEN tipo_documento = 'CNPJ'
                    THEN CONCAT(
                        doc_corpo,
                        doc_filial,
                        doc_digito
                    )
                END
        END DESC,


        /*
         * =====================================================
         * DESEMPATE ESTÁVEL POR DOCUMENTO
         * =====================================================
         *
         * Quando a ordenação principal for Nome, o documento
         * garante que registros com o mesmo nome tenham uma
         * ordem determinística.
         */

        CASE
            WHEN tipo_documento = 'CPF'
            THEN CONCAT(
                doc_corpo,
                doc_digito
            )

            WHEN tipo_documento = 'CNPJ'
            THEN CONCAT(
                doc_corpo,
                doc_filial,
                doc_digito
            )
        END ASC,


        /*
         * Último critério determinístico.
         */

        numero_requisicao ASC


    LIMIT p_limite
    OFFSET p_offset;

END$$

DELIMITER ;