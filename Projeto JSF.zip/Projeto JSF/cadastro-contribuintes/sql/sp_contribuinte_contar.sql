DROP PROCEDURE IF EXISTS sp_contribuinte_contar;

DELIMITER $$

CREATE PROCEDURE sp_contribuinte_contar(
    IN p_numero_requisicao BIGINT UNSIGNED,
    IN p_documento VARCHAR(14),
    IN p_nome VARCHAR(120)
)
BEGIN

    SELECT
        COUNT(*) AS total

    FROM cadastro_contribuintes

    WHERE

        /*
         * FILTRO POR REQUISIÇÃO
         */

        (
            p_numero_requisicao IS NULL
            OR numero_requisicao = p_numero_requisicao
        )

        AND

        /*
         * FILTRO POR DOCUMENTO
         *
         * CPF:
         *   corpo + dígito
         *
         * CNPJ:
         *   corpo + filial + dígito
         */

        (
            p_documento IS NULL
            OR p_documento = ''

            OR
            (
                tipo_documento = 'CPF'
                AND CONCAT(
                    doc_corpo,
                    doc_digito
                ) LIKE CONCAT('%', p_documento, '%')
            )

            OR
            (
                tipo_documento = 'CNPJ'
                AND CONCAT(
                    doc_corpo,
                    doc_filial,
                    doc_digito
                ) LIKE CONCAT('%', p_documento, '%')
            )
        )

        AND

        /*
         * FILTRO POR NOME
         *
         * A comparação respeita a collation do banco.
         */

        (
            p_nome IS NULL
            OR p_nome = ''

            OR razao_social_nome LIKE CONCAT(
                '%',
                TRIM(p_nome),
                '%'
            )
        );

END$$

DELIMITER ;