from pathlib import Path
from openpyxl import load_workbook


ARQUIVO_XLSX = Path(
    r"C:\Users\Nicolau\Documents\Projeto JSF\municipios jsf\RELATORIO_DTB_BRASIL_2025_MUNICIPIOS.xlsx"
)

PASTA_SAIDA = Path(
    r"C:\Users\Nicolau\Documents\Projeto JSF\cadastro-contribuintes\src\main\resources\municipios"
)


# Nome do estado -> sigla
UF_PARA_SIGLA = {
    "Acre": "AC",
    "Alagoas": "AL",
    "Amapá": "AP",
    "Amazonas": "AM",
    "Bahia": "BA",
    "Ceará": "CE",
    "Distrito Federal": "DF",
    "Espírito Santo": "ES",
    "Goiás": "GO",
    "Maranhão": "MA",
    "Mato Grosso": "MT",
    "Mato Grosso do Sul": "MS",
    "Minas Gerais": "MG",
    "Pará": "PA",
    "Paraíba": "PB",
    "Paraná": "PR",
    "Pernambuco": "PE",
    "Piauí": "PI",
    "Rio de Janeiro": "RJ",
    "Rio Grande do Norte": "RN",
    "Rio Grande do Sul": "RS",
    "Rondônia": "RO",
    "Roraima": "RR",
    "Santa Catarina": "SC",
    "São Paulo": "SP",
    "Sergipe": "SE",
    "Tocantins": "TO"
}


PASTA_SAIDA.mkdir(
    parents=True,
    exist_ok=True
)


print("Lendo a planilha...")
print(ARQUIVO_XLSX)
print()


workbook = load_workbook(
    ARQUIVO_XLSX,
    read_only=True,
    data_only=True
)

planilha = workbook.active


municipios_por_uf = {}


# A planilha possui:
# Coluna 1 = Nome_UF
# Coluna 2 = Nome_Município
for linha in planilha.iter_rows(
        min_row=2,
        values_only=True
):

    nome_uf = linha[0]
    nome_municipio = linha[1]

    if nome_uf is None or nome_municipio is None:
        continue

    nome_uf = str(nome_uf).strip()
    nome_municipio = str(nome_municipio).strip()

    sigla = UF_PARA_SIGLA.get(nome_uf)

    if sigla is None:
        print(
            f"AVISO: UF não reconhecida: {nome_uf}"
        )
        continue

    if sigla not in municipios_por_uf:
        municipios_por_uf[sigla] = set()

    municipios_por_uf[sigla].add(nome_municipio)


workbook.close()


print("Gerando arquivos...")
print()


total_municipios = 0


for nome_uf, sigla in UF_PARA_SIGLA.items():

    municipios = municipios_por_uf.get(
        sigla,
        set()
    )

    municipios = sorted(
        municipios,
        key=str.casefold
    )

    arquivo_saida = (
        PASTA_SAIDA / f"{sigla}.txt"
    )

    arquivo_saida.write_text(
        "\n".join(municipios) + "\n",
        encoding="utf-8"
    )

    quantidade = len(municipios)

    total_municipios += quantidade

    print(
        f"{sigla}.txt -> {quantidade} municípios"
    )


print()
print("========================================")
print("ARQUIVOS GERADOS COM SUCESSO!")
print("========================================")
print()
print(
    f"Total de municípios: {total_municipios}"
)
print()
print("Destino:")
print(PASTA_SAIDA)